package dev.zohir.zohirola

import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import dev.zohir.zohirola.di.installModules
import io.github.aakira.napier.DebugAntilog
import io.github.aakira.napier.Napier
import org.koin.core.context.startKoin

fun main() {
    Napier.base(DebugAntilog())
    startKoin {
        installModules()
    }
    application {
        val state = rememberWindowState(
            position = WindowPosition.PlatformDefault
        )

        Window(
            title = "Zohirola",
            onCloseRequest = ::exitApplication,
            state = state
        ) {
            App()
        }
    }
}
