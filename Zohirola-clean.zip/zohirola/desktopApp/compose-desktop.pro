-dontwarn androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffoldKt
-dontwarn org.slf4j.**
-dontwarn io.ktor.http.content.BlockingBridgeKt

-keep class io.ktor.** { *; }

-dontobfuscate
