
import com.codingfeline.buildkonfig.compiler.FieldSpec.Type.LONG
import com.codingfeline.buildkonfig.compiler.FieldSpec.Type.STRING
import org.jetbrains.kotlin.gradle.ExperimentalKotlinGradlePluginApi
import org.jetbrains.kotlin.gradle.ExperimentalWasmDsl
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.targets.js.webpack.KotlinWebpackConfig

plugins {
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.androidKotlinMultiplatformLibrary)
    alias(libs.plugins.composeMultiplatform)
    alias(libs.plugins.composeCompiler)
    alias(libs.plugins.ksp)
    alias(libs.plugins.serialization)
    alias(libs.plugins.ktorfit)
    alias(libs.plugins.koin.compiler)
    alias(libs.plugins.buildkonfig)
}

kotlin {
    android {
        namespace = "dev.zohir.zohirola"
        compileSdk = libs.versions.android.compileSdk.get().toInt()
        minSdk = libs.versions.android.minSdk.get().toInt()

        androidResources {
            enable = true
        }

        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_21)
        }
    }

    listOf(
        iosArm64(),
        iosSimulatorArm64()
    ).forEach { iosTarget ->
        iosTarget.binaries.framework {
            baseName = "shared"
            isStatic = true
        }
    }

    jvm()

    @OptIn(ExperimentalWasmDsl::class)
    wasmJs {
        outputModuleName = "zohirola"
        browser {
            commonWebpackConfig {
                outputFileName = "zohirola.js"
                devServer = (devServer ?: KotlinWebpackConfig.DevServer()).apply {
                    static = (static ?: mutableListOf()).apply {
                        add(project.rootDir.path)
                        add(project.projectDir.path)
                    }
                }
            }
        }
        compilerOptions {
            freeCompilerArgs.add("-Xwasm-debugger-custom-formatters")
        }
        binaries.executable()
    }

    @OptIn(ExperimentalKotlinGradlePluginApi::class)
    dependencies {
        // Core
        implementation(libs.compose.runtime)
        implementation(libs.compose.animation)
        implementation(libs.androidx.lifecycle.runtime.compose)
        implementation(libs.androidx.lifecycle.viewmodel)
        implementation(libs.androidx.navigation)

        // UI
        implementation(libs.compose.foundation)
        implementation(libs.compose.material3)
        implementation(libs.compose.material3AdaptiveNavigationSuite)
        implementation(libs.compose.ui)
        implementation(libs.compose.components.resources)
        implementation(libs.compose.components.uiToolingPreview)
        implementation(libs.compose.adaptive)
        implementation(libs.compose.window.size)

        // Media
        implementation(libs.coil)
        implementation(libs.coil.network)
        implementation(libs.compose.media.player)

        // DI
        api(libs.koin)
        implementation(libs.koin.annotations)
        implementation(libs.koin.compose)
        implementation(libs.koin.viewmodel)

        // Network
        implementation(libs.ktor.client.core)
        implementation(libs.ktor.client.content.negotiation)
        implementation(libs.ktor.logging)
        implementation(libs.ktor.serialization.kotlinx.json)
        implementation(libs.ktorfit)
        ksp {
            libs.ktorfit
        }

        // Database
        implementation(libs.kv)
        implementation(libs.kv.coroutines)

        // Paging
        implementation(libs.paging)
        implementation(libs.paging.compose)

        // Logging
        api(libs.logging)

        // Misc
        implementation(libs.kotlinx.datetime)
    }

    sourceSets {
        androidMain {
            dependencies {
                // Database
                implementation(libs.kv.datastore)
                implementation(libs.androidx.datastore)
            }
        }

        jvmMain {
            dependencies {
                // Database
                implementation(libs.kv.datastore)
                implementation(libs.androidx.datastore)
            }
        }

        wasmJsMain {
            dependencies {
                // Database
                implementation(libs.kv.observable)
            }
        }
    }
}

buildkonfig {
    packageName = "dev.zohir.zohirola"

    defaultConfigs {
        buildConfigField(LONG, "versionCode", libs.versions.version.code.get())
        buildConfigField(STRING, "versionName", libs.versions.version.name.get())
    }
}

dependencies {
    androidRuntimeClasspath(libs.compose.components.uiToolingPreview)
}

// https://github.com/InsertKoinIO/koin/issues/2381
koinCompiler {
    compileSafety = false
}
