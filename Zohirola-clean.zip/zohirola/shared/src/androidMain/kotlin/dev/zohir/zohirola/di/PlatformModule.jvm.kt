package dev.zohir.zohirola.di

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.russhwolf.settings.ExperimentalSettingsApi
import com.russhwolf.settings.ExperimentalSettingsImplementation
import com.russhwolf.settings.coroutines.FlowSettings
import com.russhwolf.settings.datastore.DataStoreSettings
import kotlinx.coroutines.Dispatchers
import okio.Path.Companion.toPath
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.Module
import org.koin.core.qualifier.named
import org.koin.dsl.module

@OptIn(
    ExperimentalSettingsApi::class,
    ExperimentalSettingsImplementation::class
)
actual fun platformModule(): Module = module {
    single { Platform.Android }
    single(named("io")) { Dispatchers.IO }
    single<String>(named("image")) {
        "${androidContext().cacheDir.absolutePath}/images"
    }
    single<String>(named("store")) {
        androidContext().filesDir.absolutePath
    }
    single<FlowSettings> {
        DataStoreSettings(
            PreferenceDataStoreFactory.createWithPath {
                "${get<String>(named("store"))}/zohirola.preferences_pb".toPath()
            }
        )
    }
}
