package dev.zohir.zohirola.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
actual fun BrowserHistorySync(authed: Boolean, navController: NavHostController) {}
