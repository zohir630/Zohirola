package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.paginators.base.IntegerPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class HomePaginator(
    private val zohirolaRepository: ZohirolaRepository
): IntegerPagingSource<Post>() {

    override suspend fun fetchPage(page: Int): List<Post> = zohirolaRepository.getTimeline(page).items

}
