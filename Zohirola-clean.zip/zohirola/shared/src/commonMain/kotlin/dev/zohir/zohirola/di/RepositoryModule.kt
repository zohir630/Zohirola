package dev.zohir.zohirola.di

import com.russhwolf.settings.ExperimentalSettingsApi
import dev.zohir.zohirola.repository.AuthRepository
import dev.zohir.zohirola.repository.AuthRepositoryImpl
import dev.zohir.zohirola.repository.EventBusRepository
import dev.zohir.zohirola.repository.EventBusRepositoryImpl
import dev.zohir.zohirola.repository.ZohirolaRepository
import dev.zohir.zohirola.repository.ZohirolaRepositoryImpl
import dev.zohir.zohirola.repository.StoreRepository
import dev.zohir.zohirola.repository.StoreRepositoryImpl
import org.koin.dsl.bind
import org.koin.dsl.module
import org.koin.plugin.module.dsl.single

@OptIn(ExperimentalSettingsApi::class)
object RepositoryModule {
    val repositoryModule = module {
        single<ZohirolaRepositoryImpl>() bind ZohirolaRepository::class
        single<StoreRepositoryImpl>() bind StoreRepository::class
        single<AuthRepositoryImpl>() bind AuthRepository::class
        single<EventBusRepositoryImpl>() bind EventBusRepository::class
    }
}
