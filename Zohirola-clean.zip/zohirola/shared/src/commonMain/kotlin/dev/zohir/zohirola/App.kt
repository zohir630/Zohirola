package dev.zohir.zohirola

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import coil3.ImageLoader
import coil3.compose.LocalPlatformContext
import coil3.compose.setSingletonImageLoaderFactory
import dev.zohir.zohirola.repository.StoreRepository
import dev.zohir.zohirola.ui.Navigation
import dev.zohir.zohirola.ui.theme.getTheme
import dev.zohir.zohirola.util.OnLayoutChange
import dev.zohir.zohirola.util.ktx.LayoutType
import org.koin.compose.koinInject
import org.koin.core.parameter.parametersOf

val LocalNavController = staticCompositionLocalOf<NavHostController> { error("No Navigator") }
val LocalSnackbar = staticCompositionLocalOf<SnackbarHostState> { error("No SnackbarHostState") }
val LocalLayoutType = compositionLocalOf<LayoutType> { error("No LayoutType") }
val LocalInstanceInfo = compositionLocalOf<InstanceInfoState?> { error("No InstanceInfoState") }

@Composable
fun App() {
    val ctx = LocalPlatformContext.current

    val theme = getTheme()

    MaterialTheme(
        colorScheme = theme.colorScheme,
        typography = theme.typography
    ) {
        val navController = rememberNavController()
        val snackbarHostState = remember { SnackbarHostState() }

        val storeRepository = koinInject<StoreRepository>()
        val instanceInfo = storeRepository.getInstanceInfoFlow().collectAsStateWithLifecycle(null).value

        val loader = koinInject<ImageLoader>(parameters = { parametersOf(ctx) })

        setSingletonImageLoaderFactory { loader }

        var layoutType by remember { mutableStateOf(LayoutType.Compact) }

        OnLayoutChange { layout ->
            layoutType = layout
        }

        CompositionLocalProvider(
            LocalNavController provides navController,
            LocalSnackbar provides snackbarHostState,
            LocalLayoutType provides layoutType,
            LocalInstanceInfo provides instanceInfo
        ) {
            Navigation()
        }
    }
}

data class InstanceInfoState(
    val token: String?,
    val fqdn: String?,
    val version: Int,
    val following: Boolean,
    val timeline: Boolean,
    val registration: Boolean,
    val nsfw: Boolean,
    val setup: Boolean
)
