package dev.zohir.zohirola.ui.screens.search

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.ActorCard
import dev.zohir.zohirola.ui.components.AdaptiveBox
import dev.zohir.zohirola.ui.components.FeedCard
import dev.zohir.zohirola.ui.components.LoadingPage
import dev.zohir.zohirola.ui.components.TopBar
import dev.zohir.zohirola.ui.components.buttons.ScrollToTopButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.ui.components.post.PostCard
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.animateScrollToTop
import dev.zohir.zohirola.util.ktx.horizontalContentPadding
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_cancel_24
import zohirola.shared.generated.resources.baseline_search_24
import zohirola.shared.generated.resources.feeds
import zohirola.shared.generated.resources.posts
import zohirola.shared.generated.resources.profiles
import zohirola.shared.generated.resources.search

@Composable
fun SearchScreen(
    viewModel: SearchViewModel = koinViewModel()
) {
    val navController = LocalNavController.current

    val state = viewModel.state.collectAsStateWithLifecycle().value

    val actors = state.actorsPager?.collectAsLazyPagingItems()
    val feeds = state.feedsPager?.collectAsLazyPagingItems()
    val posts = state.postsPager?.collectAsLazyPagingItems()

    val scope = rememberCoroutineScope()
    var search by rememberSaveable { mutableStateOf("") }
    val uri = remember { mutableStateOf<String?>(null) }

    val profilesListState = rememberLazyListState()
    val profilesShowFab by remember {
        derivedStateOf {
            profilesListState.firstVisibleItemIndex > 0
        }
    }
    val feedsListState = rememberLazyListState()
    val feedsShowFab by remember {
        derivedStateOf {
            feedsListState.firstVisibleItemIndex > 0
        }
    }
    val postsListState = rememberLazyListState()
    val postsShowFab by remember {
        derivedStateOf {
            postsListState.firstVisibleItemIndex > 0
        }
    }

    Scaffold(
        topBar = { TopBar() },
        floatingActionButton = {
            when (state.tab) {
                0 -> ScrollToTopButton(profilesShowFab) {
                    scope.launch { profilesListState.animateScrollToTop() }
                }
                1 -> ScrollToTopButton(feedsShowFab) {
                    scope.launch { feedsListState.animateScrollToTop() }
                }
                else -> ScrollToTopButton(postsShowFab) {
                    scope.launch { postsListState.animateScrollToTop() }
                }
            }
        }
    ) { padding ->
        AdaptiveBox(
            insets = padding,
        ) { insets ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(insets)
                    .horizontalContentPadding()
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { query ->
                        search = query
                        viewModel.search(query)
                    },
                    leadingIcon = {
                        Icon(
                            painterResource(Res.drawable.baseline_search_24),
                            contentDescription = null
                        )
                    },
                    trailingIcon = if (search.isNotEmpty()) {
                        {
                            IconButton(
                                onClick = {
                                    search = ""
                                }
                            ) {
                                Icon(
                                    painterResource(Res.drawable.baseline_cancel_24),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    } else null,
                    label = {
                        Text(stringResource(Res.string.search))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PrimaryTabRow(state.tab) {
                    Tab(
                        selected = true,
                        onClick = {
                            viewModel.setTab(0)
                        },
                        text = {
                            Text(
                                text = stringResource(Res.string.profiles)
                            )
                        }
                    )
                    Tab(
                        selected = true,
                        onClick = {
                            viewModel.setTab(1)
                        },
                        text = {
                            Text(
                                text = stringResource(Res.string.feeds)
                            )
                        }
                    )
                    Tab(
                        selected = true,
                        onClick = {
                            viewModel.setTab(2)
                        },
                        text = {
                            Text(
                                text = stringResource(Res.string.posts)
                            )
                        }
                    )
                }

                when {
                    search.isNotEmpty() && when (state.tab) {
                        0 -> state.actorsPager == null || actors?.loadState?.refresh is LoadState.Loading
                        1 -> state.feedsPager == null || feeds?.loadState?.refresh is LoadState.Loading
                        else -> state.postsPager == null || posts?.loadState?.refresh is LoadState.Loading
                    } -> LoadingPage()
                    else -> {
                        AnimatedContent(
                            state.tab,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            when (it) {
                                0 -> {
                                    LazyColumn(
                                        Modifier.fillMaxWidth(),
                                        state = profilesListState
                                    ) {
                                        actors?.let { actors ->
                                            itemsWithDivider(actors.itemCount) { idx ->
                                                val actor = actors[idx] ?: return@itemsWithDivider
                                                ActorCard(actor) {
                                                    navController.navigate(Route.Profile(actor.did))
                                                }
                                            }
                                        }
                                        pagerStateItem(actors)
                                    }
                                }
                                1 -> {
                                    LazyColumn(
                                        Modifier.fillMaxWidth(),
                                        state = feedsListState
                                    ) {
                                        feeds?.let { feeds ->
                                            itemsWithDivider(feeds.itemCount) { idx ->
                                                val feed = feeds[idx] ?: return@itemsWithDivider
                                                FeedCard(feed) {
                                                    navController.navigate(Route.Feed(feed.uri))
                                                }
                                            }
                                        }
                                        pagerStateItem(feeds)
                                    }
                                }
                                2 -> {
                                    LazyColumn(
                                        Modifier.fillMaxWidth(),
                                        state = postsListState
                                    ) {
                                        posts?.let { posts ->
                                            itemsWithDivider(posts.itemCount) { idx ->
                                                val post = posts[idx] ?: return@itemsWithDivider
                                                PostCard(
                                                    post,
                                                    null,
                                                    onClickUri = {
                                                        uri.value = it
                                                    }
                                                )
                                            }
                                        }
                                        pagerStateItem(posts)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            UriDialog(
                uri.value,
                onDismissRequest = {
                    uri.value = null
                }
            )
        }
    }
}
