package dev.zohir.zohirola.ui.screens.home

import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.paging.compose.collectAsLazyPagingItems
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.TopBar
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.pagerEmptyItem
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.ui.components.post.PostCard
import dev.zohir.zohirola.ui.components.post.UriDialog
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.timeline_empty

@Composable
fun HomeScreen(
    viewModel: HomeViewModel = koinViewModel()
) {
    val posts = viewModel.posts.collectAsLazyPagingItems()

    val uri = remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { TopBar() }
    ) { padding ->
        AdaptiveLazyColumn(padding) {
            pagerEmptyItem(posts, Res.string.timeline_empty)
            itemsWithDivider(posts.itemCount) { idx ->
                val post = posts[idx] ?: return@itemsWithDivider
                PostCard(
                    post,
                    post.feedOwnerName,
                    onClickUri = {
                        uri.value = it
                    }
                )
            }
            pagerStateItem(posts)
        }
        UriDialog(
            uri.value,
            onDismissRequest = {
                uri.value = null
            }
        )
    }
}
