package dev.zohir.zohirola.util

import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import dev.zohir.zohirola.util.ktx.LayoutType

@Composable
fun OnLayoutChange(
    onEvent: (layoutType: LayoutType) -> Unit
) {
    val windowSize = currentWindowAdaptiveInfo()

    LaunchedEffect(windowSize) {
        with(windowSize) {
            // Magic numbers taken from deprecated WindowWidthSizeClass
            onEvent(
                if (windowPosture.isTabletop || windowSizeClass.minWidthDp < 600) {
                    LayoutType.Compact
                } else {
                    LayoutType.Wide
                }
            )
        }
    }
}
