package dev.zohir.zohirola.util

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine as c

inline fun <T1, T2, T3, T4, T5, T6, T7, T8, R> combine(
    f1: Flow<T1>,
    f2: Flow<T2>,
    f3: Flow<T3>,
    f4: Flow<T4>,
    f5: Flow<T5>,
    f6: Flow<T6>,
    f7: Flow<T7>,
    f8: Flow<T8>,
    crossinline combination: suspend (T1, T2, T3, T4, T5, T6, T7, T8) -> R
): Flow<R> = c(
    c<T1, T2, T3, Triple<T1, T2, T3>>(f1, f2, f3, ::Triple),
    c<T4, T5, T6, Triple<T4, T5, T6>>(f4, f5, f6, ::Triple),
    c<T7, T8, Pair<T7, T8>>(f7, f8, ::Pair)
) { c1, c2, c3 ->
    combination(
        c1.first,
        c1.second,
        c1.third,
        c2.first,
        c2.second,
        c2.third,
        c3.first,
        c3.second
    )
}
