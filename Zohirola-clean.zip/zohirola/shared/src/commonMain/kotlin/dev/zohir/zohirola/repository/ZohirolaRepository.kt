package dev.zohir.zohirola.repository

import dev.zohir.zohirola.api.ZohirolaApi
import dev.zohir.zohirola.data.model.login.Credentials
import dev.zohir.zohirola.data.model.login.Token
import dev.zohir.zohirola.data.model.response.FollowingProfile
import dev.zohir.zohirola.data.model.response.InstanceInfo
import dev.zohir.zohirola.data.model.response.Paginated
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Profile
import dev.zohir.zohirola.data.model.response.profile.FeedResponse
import dev.zohir.zohirola.data.model.response.profile.PostResponse
import dev.zohir.zohirola.data.model.response.profile.PostsResponse
import dev.zohir.zohirola.data.model.response.search.SearchFeedsResponse
import dev.zohir.zohirola.data.model.response.search.SearchPostsResponse
import dev.zohir.zohirola.data.model.response.search.SearchProfilesResponse

interface ZohirolaRepository {
    // Unauthed
    suspend fun getInstanceInfo(
        fqdn: String
    ): InstanceInfo
    suspend fun login(
        username: String,
        password: String
    ): Token
    suspend fun searchProfiles(
        query: String,
        cursor: String?
    ): SearchProfilesResponse
    suspend fun searchFeeds(
        query: String,
        cursor: String?
    ): SearchFeedsResponse
    suspend fun searchPosts(
        query: String,
        cursor: String?
    ): SearchPostsResponse
    suspend fun getProfile(
        did: String
    ): Profile
    suspend fun getProfilePosts(
        did: String,
        cursor: String?
    ): PostsResponse
    suspend fun getProfilePost(
        did: String,
        id: String
    ): PostResponse
    suspend fun getProfileFeed(
        uri: String,
        cursor: String?
    ): FeedResponse

    // Authed
    suspend fun getTimeline(
        page: Int?
    ): Paginated<Post>

    suspend fun getFollowing(
        page: Int?
    ): Paginated<FollowingProfile>
    suspend fun savedPosts(
        page: Int?
    ): Paginated<Post>
    suspend fun follow(
        did: String
    )
    suspend fun unfollow(
        did: String
    )
    suspend fun savePost(
        did: String,
        id: String
    )
    suspend fun unsavePost(
        did: String,
        cid: String
    )
}

class ZohirolaRepositoryImpl(
    private val zohirolaApi: ZohirolaApi,
    private val storeRepository: StoreRepository
): ZohirolaRepository {

    // Unauthed
    override suspend fun getInstanceInfo(
        fqdn: String
    ): InstanceInfo {
        val url = "${fqdn}/api/info"
        val info = zohirolaApi.getInstanceInfo(url)
        val versionCode = info.versionCode ?: 0
        // storing will progress the setup page
        // Zohirola only officially supports version 1.0.0+ of the backend
        if (versionCode >= 100) {
            storeRepository.setInstanceFQDN(fqdn)
            storeRepository.setInstanceVersion(info.versionCode ?: 0)
            storeRepository.setRegistration(info.registration)
            storeRepository.setTimelines(info.timelines)
            storeRepository.setFollowing(info.following)
            storeRepository.setNsfw(info.nsfw)
        }
        return info
    }

    override suspend fun getProfile(
        did: String
    ): Profile = zohirolaApi.getProfile(did)

    override suspend fun searchProfiles(
        query: String,
        cursor: String?
    ): SearchProfilesResponse = zohirolaApi.searchProfiles(query, cursor)

    override suspend fun searchFeeds(
        query: String,
        cursor: String?
    ): SearchFeedsResponse = zohirolaApi.searchFeeds(query, cursor)

    override suspend fun searchPosts(
        query: String,
        cursor: String?
    ): SearchPostsResponse = zohirolaApi.searchPosts(query, cursor)

    override suspend fun login(
        username: String,
        password: String
    ): Token = zohirolaApi.login(Credentials(username, password))

    override suspend fun getProfilePosts(
        did: String,
        cursor: String?
    ): PostsResponse = zohirolaApi.getProfilePosts(did, cursor)

    override suspend fun getProfilePost(
        did: String,
        id: String
    ): PostResponse = zohirolaApi.getPost(did, id)

    override suspend fun getProfileFeed(
        uri: String,
        cursor: String?
    ): FeedResponse = zohirolaApi.getProfileFeed(uri, cursor)

    // Authed

    override suspend fun getTimeline(
        page: Int?
    ): Paginated<Post> = zohirolaApi.getTimeline(page)

    override suspend fun getFollowing(
        page: Int?
    ): Paginated<FollowingProfile> = zohirolaApi.getFollowing(page)

    override suspend fun savedPosts(
        page: Int?
    ): Paginated<Post> = zohirolaApi.savedPosts(page)

    override suspend fun follow(
        did: String
    ) = zohirolaApi.follow(did)

    override suspend fun unfollow(
        did: String
    ) = zohirolaApi.unfollow(did)

    override suspend fun savePost(
        did: String,
        id: String
    ) = zohirolaApi.save(did, id)

    override suspend fun unsavePost(
        did: String,
        cid: String
    ) = zohirolaApi.unsave(did, cid)

}
