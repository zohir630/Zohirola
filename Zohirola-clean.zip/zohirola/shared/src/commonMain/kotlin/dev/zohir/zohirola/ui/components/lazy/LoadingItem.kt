package dev.zohir.zohirola.ui.components.lazy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.ui.components.buttons.IconTextButton
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_refresh_24
import zohirola.shared.generated.resources.failed_to_load
import zohirola.shared.generated.resources.try_again

fun LazyListScope.loading() = item {
    Box(
        Modifier.fillParentMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

// For use in PagingSource data
fun LazyListScope.loadingPage(
    padding: PaddingValues = PaddingValues(0.dp)
) = item {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(padding),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

fun LazyListScope.tryAgain(
    message: String?,
    onClick: (() -> Unit)? = null
) = item {
    Column(
        Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(Res.string.failed_to_load))
        if (message != null) {
            Text(message)
        }
        if (onClick != null) {
            IconTextButton(
                icon = painterResource(Res.drawable.baseline_refresh_24),
                text = stringResource(Res.string.try_again),
                onClick = onClick
            )
        }
    }
}
