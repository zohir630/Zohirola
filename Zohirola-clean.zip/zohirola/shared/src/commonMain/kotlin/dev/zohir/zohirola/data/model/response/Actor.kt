package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Actor(
    val did: String,
    val handle: String,
    val displayName: String? = null,
    val description: String? = null,
    val avatar: String? = null
)
