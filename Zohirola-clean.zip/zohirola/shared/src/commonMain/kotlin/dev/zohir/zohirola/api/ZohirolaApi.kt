package dev.zohir.zohirola.api

import de.jensklingenberg.ktorfit.http.Body
import de.jensklingenberg.ktorfit.http.DELETE
import de.jensklingenberg.ktorfit.http.GET
import de.jensklingenberg.ktorfit.http.POST
import de.jensklingenberg.ktorfit.http.PUT
import de.jensklingenberg.ktorfit.http.Path
import de.jensklingenberg.ktorfit.http.Query
import de.jensklingenberg.ktorfit.http.Url
import dev.zohir.zohirola.data.model.login.Credentials
import dev.zohir.zohirola.data.model.login.Token
import dev.zohir.zohirola.data.model.response.FollowingProfile
import dev.zohir.zohirola.data.model.response.InstanceInfo
import dev.zohir.zohirola.data.model.response.Paginated
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Profile
import dev.zohir.zohirola.data.model.response.profile.FeedResponse
import dev.zohir.zohirola.data.model.response.profile.PostResponse
import dev.zohir.zohirola.data.model.response.profile.PostsResponse
import dev.zohir.zohirola.data.model.response.search.SearchFeedsResponse
import dev.zohir.zohirola.data.model.response.search.SearchPostsResponse
import dev.zohir.zohirola.data.model.response.search.SearchProfilesResponse
import dev.zohir.zohirola.plugins.Authed
import dev.zohir.zohirola.plugins.CallOnce
import dev.zohir.zohirola.plugins.OptionalAuth
import dev.zohir.zohirola.plugins.Passthrough

interface ZohirolaApi {

    // Unauthed
    @GET
    @Passthrough
    suspend fun getInstanceInfo(
        @Url url: String
    ): InstanceInfo

    @POST("login")
    @CallOnce
    suspend fun login(
        @Body login: Credentials
    ): Token

    @GET("search/profiles")
    suspend fun searchProfiles(
        @Query("q") query: String,
        @Query("cursor") cursor: String?
    ): SearchProfilesResponse

    @GET("search/feeds")
    suspend fun searchFeeds(
        @Query("q") query: String,
        @Query("cursor") cursor: String?
    ): SearchFeedsResponse

    @GET("search/posts")
    suspend fun searchPosts(
        @Query("q") query: String,
        @Query("cursor") cursor: String?
    ): SearchPostsResponse

    @GET("profile/{handle}")
    @OptionalAuth
    suspend fun getProfile(
        @Path("handle") handle: String
    ): Profile

    @GET("profile/{handle}/posts")
    @OptionalAuth
    suspend fun getProfilePosts(
        @Path("handle") handle: String,
        @Query("cursor") cursor: String?
    ): PostsResponse

    @GET("profile/feed")
    @OptionalAuth
    suspend fun getProfileFeed(
        @Query("uri") uri: String, // Ktor(fit) isn't encoding URI as part of a path
        @Query("cursor") cursor: String?
    ): FeedResponse

    @GET("profile/{handle}/post/{id}")
    @OptionalAuth
    suspend fun getPost(
        @Path("handle") handle: String,
        @Path("id") id: String
    ): PostResponse

    // Authed

    @GET("user/timeline")
    @Authed
    suspend fun getTimeline(
        @Query("page") page: Int? = null
    ): Paginated<Post>

    @GET("user/following")
    @Authed
    suspend fun getFollowing(
        @Query("page") page: Int?
    ): Paginated<FollowingProfile>

    @GET("user/saved")
    @Authed
    suspend fun savedPosts(
        @Query("page") page: Int?
    ): Paginated<Post>

    @PUT("profile/{did}/follow")
    @Authed
    suspend fun follow(
        @Path("did") did: String
    )

    @DELETE("profile/{did}/unfollow")
    @Authed
    suspend fun unfollow(
        @Path("did") did: String
    )

    @PUT("profile/{did}/post/{id}/save")
    @Authed
    suspend fun save(
        @Path("did") did: String,
        @Path("id") id: String
    )

    @DELETE("profile/{did}/post/{cid}/unsave")
    @Authed
    suspend fun unsave(
        @Path("did") did: String,
        @Path("cid") id: String
    )

}
