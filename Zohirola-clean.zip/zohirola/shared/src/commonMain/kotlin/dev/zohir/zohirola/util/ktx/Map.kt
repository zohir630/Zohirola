package dev.zohir.zohirola.util.ktx

fun <K, V> Map<out K, V>.assertivelyGet(k: K): V = this[k]!!
