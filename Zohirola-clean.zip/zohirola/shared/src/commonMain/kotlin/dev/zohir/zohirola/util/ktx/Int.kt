package dev.zohir.zohirola.util.ktx

fun Int.format(): String {
    return when {
        this >= 1_000_000 -> "${(this.toDouble() / 1_000_000).round(1)}m"
        this >= 1_000 -> "${(this.toDouble() / 1_000).round(1)}k"
        else -> "$this"
    }
}
