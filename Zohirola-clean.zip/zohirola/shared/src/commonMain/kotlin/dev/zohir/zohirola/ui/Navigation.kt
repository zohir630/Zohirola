package dev.zohir.zohirola.ui

import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.waterfallPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffoldValue
import androidx.compose.material3.adaptive.navigationsuite.rememberNavigationSuiteScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.dialog
import androidx.navigation.navDeepLink
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.LocalSnackbar
import dev.zohir.zohirola.data.AuthExpired
import dev.zohir.zohirola.data.Custom
import dev.zohir.zohirola.data.CustomResource
import dev.zohir.zohirola.data.Event
import dev.zohir.zohirola.data.RequiresAuth
import dev.zohir.zohirola.repository.EventBusRepository
import dev.zohir.zohirola.ui.components.LoadingPage
import dev.zohir.zohirola.ui.screens.feed.FeedScreen
import dev.zohir.zohirola.ui.screens.following.FollowingScreen
import dev.zohir.zohirola.ui.screens.home.HomeScreen
import dev.zohir.zohirola.ui.screens.image.ImageScreen
import dev.zohir.zohirola.ui.screens.post.PostScreen
import dev.zohir.zohirola.ui.screens.profile.ProfileScreen
import dev.zohir.zohirola.ui.screens.saved.SavedScreen
import dev.zohir.zohirola.ui.screens.search.SearchScreen
import dev.zohir.zohirola.ui.screens.settings.SettingsScreen
import dev.zohir.zohirola.ui.screens.setup.SetupScreen
import dev.zohir.zohirola.util.ktx.assertivelyGet
import dev.zohir.zohirola.util.ktx.loginPrompt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.unknown_error

private const val ROOT_UPSTREAM_URI = "https://bsky.app"

@Composable
fun Navigation(
    viewModel: RootViewModel = koinViewModel(),
    events: Flow<Event> = viewModel.bus
) {
    val navController = LocalNavController.current
    val snackbar = LocalSnackbar.current
    val instanceInfo = LocalInstanceInfo.current

    LaunchedEffect(events) {
        events.collectLatest { event ->
            when (event) {
                is RequiresAuth,
                is AuthExpired -> snackbar.loginPrompt(expired = event is AuthExpired) {
                    navController.navigate(Route.Setup)
                }
                is Custom -> snackbar.showSnackbar(
                    event.string ?: getString(Res.string.unknown_error),
                    withDismissAction = event.dismissable,
                    duration = event.duration
                )
                is CustomResource -> snackbar.showSnackbar(
                    getString(event.resource, formatArgs = event.parameters),
                    withDismissAction = event.dismissable,
                    duration = event.duration
                )
            }
        }
    }

    instanceInfo ?: return LoadingPage()

    val backStack = navController.currentBackStackEntryAsState().value?.destination
    val navScaffoldState = rememberNavigationSuiteScaffoldState(NavigationSuiteScaffoldValue.Hidden)

    val scaffoldInfo = remember(instanceInfo) {
        derivedStateOf {
            ScaffoldInfo(
                isSetup = instanceInfo.setup,
                navRoutes = if (instanceInfo.token != null) Route.bottomNavRoutes else Route.unauthedBottomNavRoutes
            )
        }
    }.value

    LaunchedEffect(backStack) {
        if (scaffoldInfo.navRoutes.any { backStack?.hasRoute(it.route::class.qualifiedName.toString(), null) == true }) {
            if (navScaffoldState.currentValue != NavigationSuiteScaffoldValue.Visible) {
                navScaffoldState.show()
            }
        } else {
            if (navScaffoldState.currentValue != NavigationSuiteScaffoldValue.Hidden) {
                navScaffoldState.hide()
            }
        }
    }

    BrowserHistorySync(
        authed = instanceInfo.token != null,
        navController = navController
    )

    NavigationSuiteScaffold(
        state = navScaffoldState,
        navigationSuiteItems = {
            scaffoldInfo.navRoutes.forEach { route ->
                item(
                    icon = {
                        Icon(
                            painterResource(Route.iconMap.assertivelyGet(route.route)),
                            contentDescription = null
                        )
                    },
                    selected = backStack?.hasRoute(route.route::class.qualifiedName.toString(), null) == true,
                    onClick = {
                        navController.navigate(route.route)
                    }
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = {
                SnackbarHost(snackbar)
            },
        ) {
            NavHost(
                navController,
                when {
                    !scaffoldInfo.isSetup -> Route.Setup
                    else -> scaffoldInfo.navRoutes.find { it.route == Route.BottomNavRoute.Home }?.route ?: Route.BottomNavRoute.Search
                },
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .waterfallPadding()
                    .displayCutoutPadding()
            ) {
                composable<Route.BottomNavRoute.Home> {
                    HomeScreen()
                }
                composable<Route.BottomNavRoute.Search> {
                    SearchScreen()
                }
                composable<Route.BottomNavRoute.Following> {
                    FollowingScreen()
                }
                composable<Route.BottomNavRoute.Saved> {
                    SavedScreen()
                }

                composable<Route.Setup> {
                    SetupScreen()
                }
                composable<Route.Profile>(
                    deepLinks = listOf(
                        navDeepLink {
                            uriPattern = "${ROOT_UPSTREAM_URI}/profile/{did}"
                        }
                    )
                ) {
                    ProfileScreen()
                }
                composable<Route.Post>(
                    deepLinks = listOf(
                        navDeepLink {
                            uriPattern = "${ROOT_UPSTREAM_URI}/profile/{did}/post/{id}"
                        }
                    )
                ) {
                    PostScreen()
                }
                composable<Route.Feed> {
                    FeedScreen()
                }
                composable<Route.Settings> {
                    SettingsScreen()
                }

                dialog<Route.Images> {
                    ImageScreen()
                }
            }
        }
    }
}

class RootViewModel(
    eventBus: EventBusRepository
): ViewModel() {
    val bus = eventBus.bus
}

private data class ScaffoldInfo(
    val isSetup: Boolean,
    val navRoutes: List<BottomNavRouteEntry>
)
