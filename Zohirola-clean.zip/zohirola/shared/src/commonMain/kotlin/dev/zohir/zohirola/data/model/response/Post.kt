package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Post(
    val id: String,
    val cid: String,
    val feedOwner: String?,
    val feedOwnerName: String?,
    val content: String?,
    val images: List<String>?,
    val playlist: String?,
    val playlistThumbnail: String?,
    val externalUri: String? = null,
    val externalTitle: String? = null,
    val externalDescription: String? = null,
    val externalThumb: String? = null,
    val nsfw: Boolean,
    val likeCount: Int?,
    val replyCount: Int?,
    val quoteCount: Int?,
    val pin: Boolean,
    val repost: Boolean,
    val repostedAt: String?,
    val createdAt: String?,
    val authorDid: String,
    val authorAvatar: String?,
    val authorHandle: String,
    val authorName: String?,
    val quotedDid: String?,
    val quotedId: String?
)
