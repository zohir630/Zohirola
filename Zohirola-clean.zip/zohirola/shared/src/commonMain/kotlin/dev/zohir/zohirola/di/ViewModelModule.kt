package dev.zohir.zohirola.di

import dev.zohir.zohirola.ui.RootViewModel
import dev.zohir.zohirola.ui.screens.feed.FeedViewModel
import dev.zohir.zohirola.ui.screens.following.FollowingViewModel
import dev.zohir.zohirola.ui.screens.home.HomeViewModel
import dev.zohir.zohirola.ui.screens.image.ImageViewModel
import dev.zohir.zohirola.ui.screens.post.PostViewModel
import dev.zohir.zohirola.ui.screens.profile.ProfileViewModel
import dev.zohir.zohirola.ui.screens.saved.SavedViewModel
import dev.zohir.zohirola.ui.screens.search.SearchViewModel
import dev.zohir.zohirola.ui.screens.settings.SettingsViewModel
import dev.zohir.zohirola.ui.screens.setup.SetupViewModel
import org.koin.dsl.module
import org.koin.plugin.module.dsl.factory

object ViewModelModule {
    val viewModelModule = module {
        factory<RootViewModel>()
        factory<SetupViewModel>()
        factory<HomeViewModel>()
        factory<SearchViewModel>()
        factory<ProfileViewModel>()
        factory<PostViewModel>()
        factory<SavedViewModel>()
        factory<FeedViewModel>()
        factory<FollowingViewModel>()
        factory<ImageViewModel>()
        factory<SettingsViewModel>()
    }
}
