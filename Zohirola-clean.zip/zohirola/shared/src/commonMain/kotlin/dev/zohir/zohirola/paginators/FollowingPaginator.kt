package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.FollowingProfile
import dev.zohir.zohirola.paginators.base.IntegerPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class FollowingPaginator(
    private val zohirolaRepository: ZohirolaRepository
): IntegerPagingSource<FollowingProfile>() {

    override suspend fun fetchPage(page: Int): List<FollowingProfile> = zohirolaRepository.getFollowing(page).items

}
