package dev.zohir.zohirola.ui.screens.image

class ImageContract {

    data class ImageState(
        val images: List<String>?,
        val fullsize: List<String>?,
        val failedFullsize: Set<Int>,
        val idx: Int
    )

}
