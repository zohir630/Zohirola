package dev.zohir.zohirola.di

import coil3.ImageLoader
import coil3.disk.DiskCache
import coil3.memory.MemoryCache
import dev.zohir.zohirola.util.ktx.applyIf
import kotlinx.serialization.json.Json
import okio.Path.Companion.toPath
import org.koin.core.qualifier.named
import org.koin.dsl.module

enum class Platform {
    Android,
    iOS,
    JVM,
    Web
}

object AppModule {
    val appModule = module {
        single {
            Json {
                ignoreUnknownKeys = true
            }
        }
        single { parameters ->
            ImageLoader.Builder(parameters.get())
                .memoryCache {
                    MemoryCache.Builder()
                        .maxSizePercent(parameters.get())
                        .build()
                }
                .applyIf(get<Platform>() != Platform.Web) {
                    diskCache {
                        DiskCache.Builder()
                            .directory(get<String>(named("image")).toPath())
                            .maxSizePercent(0.01)
                            .build()
                    }
                }
                .build()
        }
    }
}
