package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.util.ktx.toClipEntry
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.copy_bluesky_link
import zohirola.shared.generated.resources.copy_zohirola_link

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareSheet(
    uri: String?,
    onDismissRequest: () -> Unit
) {
    val instanceInfo = LocalInstanceInfo.current
    val clipboard = LocalClipboard.current

    val state = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()

    if (uri != null) {
        ModalBottomSheet(
            sheetState = state,
            onDismissRequest = onDismissRequest
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        scope.launch {
                            clipboard.setClipEntry("https://bsky.app${uri}".toClipEntry())
                            state.hide()
                            onDismissRequest()
                        }
                    }
                ) {
                    Text(stringResource(Res.string.copy_bluesky_link))
                }
                Button(
                    onClick = {
                        scope.launch {
                            clipboard.setClipEntry("${instanceInfo?.fqdn}${uri}".toClipEntry())
                            state.hide()
                            onDismissRequest()
                        }
                    }
                ) {
                    Text(stringResource(Res.string.copy_zohirola_link))
                }
            }
        }
    }
}
