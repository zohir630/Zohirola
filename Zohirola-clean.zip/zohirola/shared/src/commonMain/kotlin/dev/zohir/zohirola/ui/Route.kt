package dev.zohir.zohirola.ui

import kotlinx.serialization.Serializable
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_bookmark_24
import zohirola.shared.generated.resources.baseline_group_24
import zohirola.shared.generated.resources.baseline_home_24
import zohirola.shared.generated.resources.baseline_search_24

object Route {
    @Serializable
    data object Setup

    @Serializable
    data class Profile(val did: String)

    @Serializable
    data class Post(
        val did: String,
        val id: String
    )

    @Serializable
    data object Settings

    @Serializable
    data class Images(
        val images: List<String>,
        val idx: Int
    )

    @Serializable
    data class Feed(
        val uri: String
    )

    @Serializable
    sealed class BottomNavRoute(
        val path: String
    ) {
        @Serializable
        data object Home: BottomNavRoute("home")

        @Serializable
        data object Search: BottomNavRoute("search")

        @Serializable
        data object Following: BottomNavRoute("following")

        @Serializable
        data object Saved: BottomNavRoute("saved")
    }

    val bottomNavRoutes = listOf(
        BottomNavRouteEntry(BottomNavRoute.Home),
        BottomNavRouteEntry(BottomNavRoute.Search),
        BottomNavRouteEntry(BottomNavRoute.Following),
        BottomNavRouteEntry(BottomNavRoute.Saved),
    )
    val unauthedBottomNavRoutes = listOf(
        BottomNavRouteEntry(BottomNavRoute.Search)
    )
    val iconMap = mapOf(
        BottomNavRoute.Home to Res.drawable.baseline_home_24,
        BottomNavRoute.Search to Res.drawable.baseline_search_24,
        BottomNavRoute.Following to Res.drawable.baseline_group_24,
        BottomNavRoute.Saved to Res.drawable.baseline_bookmark_24
    )
}

@Serializable
data class BottomNavRouteEntry(
    val route: Route.BottomNavRoute
)
