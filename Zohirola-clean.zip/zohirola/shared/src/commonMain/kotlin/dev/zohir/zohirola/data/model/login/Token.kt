package dev.zohir.zohirola.data.model.login

import kotlinx.serialization.Serializable

@Serializable
data class Token(
    val token: String
)
