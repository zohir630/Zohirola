package dev.zohir.zohirola.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.zohir.zohirola.BuildKonfig
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.LocalSnackbar
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.BackTopBar
import dev.zohir.zohirola.ui.components.SettingsSection
import dev.zohir.zohirola.ui.components.SettingsTile
import dev.zohir.zohirola.util.ktx.dismissableSnackbar
import dev.zohir.zohirola.util.ktx.horizontalContentPadding
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import dev.zohir.zohirola.util.ktx.round
import io.github.kdroidfilter.composemediaplayer.AudioMode
import io.github.kdroidfilter.composemediaplayer.CacheConfig
import io.github.kdroidfilter.composemediaplayer.InterruptionMode
import io.github.kdroidfilter.composemediaplayer.rememberVideoPlayerState
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.about
import zohirola.shared.generated.resources.about_build
import zohirola.shared.generated.resources.about_version
import zohirola.shared.generated.resources.app
import zohirola.shared.generated.resources.app_name
import zohirola.shared.generated.resources.baseline_check_24
import zohirola.shared.generated.resources.baseline_close_24
import zohirola.shared.generated.resources.clear_image_cache
import zohirola.shared.generated.resources.clear_image_cache_description
import zohirola.shared.generated.resources.disk_cache_size
import zohirola.shared.generated.resources.image_cache_cleared
import zohirola.shared.generated.resources.image_cache_size
import zohirola.shared.generated.resources.instance
import zohirola.shared.generated.resources.instance_features
import zohirola.shared.generated.resources.login_button
import zohirola.shared.generated.resources.login_description
import zohirola.shared.generated.resources.login_more_features
import zohirola.shared.generated.resources.memory_cache_size
import zohirola.shared.generated.resources.refresh_instance_features
import zohirola.shared.generated.resources.refresh_instance_features_description
import zohirola.shared.generated.resources.reset_zohirola
import zohirola.shared.generated.resources.reset_zohirola_description
import zohirola.shared.generated.resources.server_feature_following_short
import zohirola.shared.generated.resources.server_feature_nsfw_short
import zohirola.shared.generated.resources.server_feature_registration_short
import zohirola.shared.generated.resources.server_feature_timeline_short
import zohirola.shared.generated.resources.settings

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = koinViewModel()
) {
    val navController = LocalNavController.current
    val snackbar = LocalSnackbar.current
    val instanceInfo = LocalInstanceInfo.current

    val scope = rememberCoroutineScope()

    val state by viewModel.state.collectAsStateWithLifecycle()
    val videoState = rememberVideoPlayerState(
        audioMode = AudioMode(InterruptionMode.DuckOthers),
        cacheConfig = CacheConfig(
            enabled = true
        )
    )

    Scaffold(
        topBar = {
            BackTopBar()
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .horizontalContentPadding()
        ) {
            Text(
                stringResource(Res.string.settings),
                fontSize = 36.sp
            )
            if (instanceInfo?.token == null) {
                LoginFeaturesBanner(
                    onClick = {
                        navController.navigate(Route.Setup)
                    }
                )
            }

            // Instance
            SettingsSection(
                title = stringResource(Res.string.instance)
            ) {
                InstanceFeatures()
                SettingsTile(
                    title = stringResource(Res.string.refresh_instance_features),
                    description = stringResource(Res.string.refresh_instance_features_description),
                    onClick = {
                        viewModel.refreshInstanceFeatures(instanceInfo?.fqdn)
                    }
                )
                if (instanceInfo != null && instanceInfo.token == null && instanceInfo.registration) {
                    SettingsTile(
                        title = stringResource(Res.string.login_button),
                        description = stringResource(Res.string.login_description),
                        onClick = {
                            navController.navigate(Route.Setup)
                        }
                    )
                }
            }
            HorizontalDivider()

            // App
            SettingsSection(
                title = stringResource(Res.string.app)
            ) {
                ImageCacheSize(state.memoryCacheBytes, state.diskCacheBytes)
                SettingsTile(
                    title = stringResource(Res.string.clear_image_cache),
                    description = stringResource(Res.string.clear_image_cache_description),
                    onClick = {
                        videoState.clearCache()
                        viewModel.clearImageCache()
                        scope.launch {
                            snackbar.dismissableSnackbar(
                                getString(Res.string.image_cache_cleared),
                                duration = SnackbarDuration.Short
                            )
                        }
                    }
                )
                SettingsTile(
                    title = stringResource(Res.string.reset_zohirola),
                    description = stringResource(Res.string.reset_zohirola_description),
                    onClick = {
                        videoState.clearCache()
                        viewModel.wipe()
                        navController.navigate(Route.Setup)
                    }
                )
            }
            HorizontalDivider()

            // About
            SettingsSection(
                title = stringResource(Res.string.about)
            ) {
                SettingsTile(
                    title = stringResource(Res.string.app_name),
                    description = "dev.zohir.zohirola"
                )
                SettingsTile(
                    title = stringResource(Res.string.about_version, BuildKonfig.versionName),
                    description = stringResource(Res.string.about_build, BuildKonfig.versionCode)
                )
            }
        }
    }
}

@Composable
private fun LoginFeaturesBanner(
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            stringResource(Res.string.login_more_features),
            modifier = Modifier.padding(6.dp)
        )
    }
}

@Composable
private fun InstanceFeatures() {
    val instanceInfo = LocalInstanceInfo.current

    Column {
        Text(stringResource(Res.string.instance_features))
        Feature(stringResource(Res.string.server_feature_registration_short), instanceInfo?.registration)
        Feature(stringResource(Res.string.server_feature_following_short), instanceInfo?.following)
        Feature(stringResource(Res.string.server_feature_timeline_short), instanceInfo?.timeline)
        Feature(stringResource(Res.string.server_feature_nsfw_short), instanceInfo?.nsfw)
    }
}

@Composable
private fun Feature(
    feature: String,
    enabled: Boolean?
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            if (enabled == true) painterResource(Res.drawable.baseline_check_24) else painterResource(Res.drawable.baseline_close_24),
            contentDescription = null,
            modifier = Modifier
        )
        Text(
            feature,
            color = MaterialTheme.onSurfaceAlpha,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ImageCacheSize(
    memoryBytes: Long?,
    diskBytes: Long?
) {
    val formattedMemory = remember { formatBytes(memoryBytes) }
    val formattedDisk = remember { formatBytes(diskBytes) }

    Column {
        Text(stringResource(Res.string.image_cache_size))
        Text(
            stringResource(Res.string.memory_cache_size, formattedMemory),
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            stringResource(Res.string.disk_cache_size, formattedDisk),
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

const val kB = 1024.0
const val mB = kB * 1024
const val gB = mB * 1024

private fun formatBytes(bytes: Long?): String = when {
    bytes == null -> "0B"
    bytes >= gB -> "${(bytes / gB).round(2)}GB"
    bytes >= mB -> "${(bytes / mB).round(2)}MB"
    bytes >= kB -> "${(bytes / kB).round(2)}KB"
    else -> "${bytes}B"
}
