package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.paginators.base.StringPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class PostsPaginator(
    private val handle: String,
    private val zohirolaRepository: ZohirolaRepository
): StringPagingSource<Post>() {

    override suspend fun fetchPage(cursor: String?): Pair<List<Post>, String?> {
        val response = zohirolaRepository.getProfilePosts(handle, cursor)
        return response.feed to response.cursor
    }

}
