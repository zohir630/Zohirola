package dev.zohir.zohirola.ui.screens.search

import androidx.paging.PagingData
import dev.zohir.zohirola.data.model.response.Actor
import dev.zohir.zohirola.data.model.response.Feed
import dev.zohir.zohirola.data.model.response.Post
import kotlinx.coroutines.flow.Flow

class SearchContract {

    data class State(
        val actorsPager: Flow<PagingData<Actor>>?,
        val feedsPager: Flow<PagingData<Feed>>?,
        val postsPager: Flow<PagingData<Post>>?,
        val tab: Int
    )

}
