package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class FollowingProfile(
    val id: String,
    val name: String,
    val avatar: String?
)
