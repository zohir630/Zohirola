package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.data.model.response.Actor
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.at_handle

@Composable
fun ActorCard(
    actor: Actor,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            }
            .padding(vertical = (2.5).dp)
            .padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AvatarImage(actor.avatar)
        Column {
            actor.displayName?.let { displayName ->
                Text(
                    displayName,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                stringResource(Res.string.at_handle, actor.handle),
                color = MaterialTheme.onSurfaceAlpha,
                style = MaterialTheme.typography.labelLarge
            )
            actor.description?.let { description ->
                Text(
                    description,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
