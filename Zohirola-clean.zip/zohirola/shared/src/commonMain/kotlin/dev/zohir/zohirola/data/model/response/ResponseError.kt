package dev.zohir.zohirola.data.model.response

import io.ktor.http.HttpStatusCode
import kotlinx.serialization.Serializable

class ResponseError(
    zohirolaError: ZohirolaError
): Exception(zohirolaError.message) {
    val error = zohirolaError
}

class ServiceUnavailable(
    message: String
): ZohirolaError(
    HttpStatusCode.ServiceUnavailable.value,
    message,
    emptyList()
)

@Serializable
open class ZohirolaError(
    val code: Int,
    val message: String,
    val errors: List<String>? = null
)
