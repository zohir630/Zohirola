package dev.zohir.zohirola.repository

import dev.zohir.zohirola.api.ZohirolaApi
import dev.zohir.zohirola.data.model.login.Credentials
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import org.koin.core.annotation.Named

interface AuthRepository {
    suspend fun getToken(): String?
    suspend fun login(
        username: String,
        password: String
    ): String
    suspend fun requiresLogin()
    suspend fun logout()
}

class AuthRepositoryImpl(
    private val storeRepository: StoreRepository,
    private val eventBus: EventBusRepository,
    private val zohirolaApi: ZohirolaApi,
    @Named("default") private val defaultDispatcher: CoroutineDispatcher,
    @Named("io") private val ioDispatcher: CoroutineDispatcher
): AuthRepository {

    override suspend fun getToken(): String? = withContext(ioDispatcher) {
        storeRepository.getToken()
    }

    override suspend fun login(
        username: String,
        password: String
    ): String = withContext(ioDispatcher) {
        val token = zohirolaApi.login(Credentials(username, password)).token
        storeRepository.setToken(token)
        return@withContext token
    }

    override suspend fun requiresLogin() = withContext(defaultDispatcher) {
        eventBus.requiresAuth()
    }

    override suspend fun logout() = withContext(ioDispatcher) {
        storeRepository.deleteToken()
        storeRepository.setSetup(false)
        withContext(defaultDispatcher) {
            eventBus.authExpired()
        }
    }

}
