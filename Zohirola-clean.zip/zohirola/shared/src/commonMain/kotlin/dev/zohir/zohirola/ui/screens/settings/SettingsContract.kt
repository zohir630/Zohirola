package dev.zohir.zohirola.ui.screens.settings

class SettingsContract {

    data class SettingsState(
        val memoryCacheBytes: Long?,
        val diskCacheBytes: Long?
    )

}
