package dev.zohir.zohirola.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable

data class Theme(
    val colorScheme: ColorScheme,
    val typography: Typography
)

@Composable
expect fun getTheme(
    darkTheme: Boolean = isSystemInDarkTheme()
): Theme
