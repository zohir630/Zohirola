package dev.zohir.zohirola.plugins

import de.jensklingenberg.ktorfit.annotations
import dev.zohir.zohirola.repository.AuthRepository
import io.github.aakira.napier.Napier
import io.ktor.client.plugins.api.Send
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.http.HttpStatusCode

class AuthPluginConfig {
    var authRepository: Lazy<AuthRepository>? = null
}

val ZohirolaAuthPlugin = createClientPlugin(
    "ZohirolaAuthPlugin",
    ::AuthPluginConfig
) {
    on(Send) { request ->
        val required = request.annotations.filterIsInstance<Authed>().isNotEmpty()
        val optional = request.annotations.filterIsInstance<OptionalAuth>().isNotEmpty()
        if (!required && !optional) return@on proceed(request)
        val repository = this@createClientPlugin.pluginConfig.authRepository?.value
        val token = repository?.getToken()
        when {
            required -> {
                if (token == null) {
                    Napier.d("No auth")
                    repository?.requiresLogin()
                    return@on proceed(request)
                } else {
                    request.headers["Authorization"] = "Bearer $token"
                    proceed(request).response.run {
                        if (status == HttpStatusCode.Unauthorized) {
                            if (request.annotations.filterIsInstance<CallOnce>().isNotEmpty()) return@run call
                            Napier.d("Auth-expired re-authenticating")
                            repository.logout()
                            return@on call
                        } else {
                            return@on call
                        }
                    }
                }
            }
            optional && token != null -> {
                Napier.d("Sending optional auth - token provided")
                request.headers["Authorization"] = "Bearer $token"
                return@on proceed(request)
            }
        }
        return@on proceed(request)
    }
}
