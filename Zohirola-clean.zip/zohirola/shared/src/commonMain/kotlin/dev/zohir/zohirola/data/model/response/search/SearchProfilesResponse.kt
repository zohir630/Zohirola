package dev.zohir.zohirola.data.model.response.search

import dev.zohir.zohirola.data.model.response.Actor
import kotlinx.serialization.Serializable

@Serializable
data class SearchProfilesResponse(
    val actors: List<Actor>,
    val cursor: String?
)
