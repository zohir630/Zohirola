package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Feed(
    val uri: String,
    val displayName: String?,
    val description: String?,
    val avatar: String?,
    val likeCount: Long,
    val creator: FeedCreator
)

@Serializable
data class FeedCreator(
    val handle: String
)
