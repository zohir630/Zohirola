package dev.zohir.zohirola.ui.screens.feed

import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.paging.compose.collectAsLazyPagingItems
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.buttons.BackButton
import dev.zohir.zohirola.ui.components.buttons.ScrollToTopButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.ui.components.post.PostCard
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.animateScrollToTop
import kotlinx.coroutines.launch
import org.koin.compose.viewmodel.koinViewModel

@Composable
fun FeedScreen(
    viewModel: FeedViewModel = koinViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val posts = state.pager?.collectAsLazyPagingItems()

    val scope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    val uri = remember { mutableStateOf<String?>(null) }

    val showScrollFab by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex > 0
        }
    }

    PullToRefreshBox(
        state.refresh,
        onRefresh = {
            viewModel.updateState()
        }
    ) {
        Scaffold(
            topBar = { BackButton() },
            floatingActionButton = {
                ScrollToTopButton(showScrollFab) {
                    scope.launch {
                        lazyListState.animateScrollToTop()
                    }
                }
            }
        ) { padding ->
            AdaptiveLazyColumn(
                padding,
                contentPadding = 0.dp,
                state = lazyListState
            ) {
                posts?.let { posts ->
                    itemsWithDivider(posts.itemCount) { idx ->
                        val post = posts[idx] ?: return@itemsWithDivider
                        PostCard(
                            post,
                            null,
                            onClickUri = {
                                uri.value = it
                            }
                        )
                    }
                }
                pagerStateItem(posts)
            }
            UriDialog(
                uri.value,
                onDismissRequest = {
                    uri.value = null
                }
            )
        }
    }
}
