package dev.zohir.zohirola.ui.components.lazy

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource

fun <T: Any> LazyListScope.pagerStateItem(
    items: LazyPagingItems<T>?
) {
    if (items?.loadState?.hasError == true) {
        return tryAgain(
            null,
            onClick = {
                items.retry()
            }
        )
    }
    when (items?.loadState?.append) {
        is LoadState.Loading -> {
            loadingPage(PaddingValues(top = 12.dp))
        }
        is LoadState.Error -> {
            tryAgain(
                (items.loadState.append as LoadState.Error).error.message,
                onClick = {
                    items.retry()
                }
            )
        }
        else -> {}
    }
}

fun <T: Any> LazyListScope.pagerEmptyItem(
    items: LazyPagingItems<T>?,
    stringResource: StringResource
) = item {
    if (items?.loadState?.isIdle == true && !items.loadState.hasError && items.itemCount == 0) {
        Text(
            stringResource(stringResource),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            textAlign = TextAlign.Center
        )
    }
}
