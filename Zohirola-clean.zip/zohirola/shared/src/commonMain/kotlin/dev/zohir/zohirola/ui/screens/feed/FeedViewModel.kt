package dev.zohir.zohirola.ui.screens.feed

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import dev.zohir.zohirola.paginators.FeedPaginator
import io.github.aakira.napier.Napier
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.Named
import org.koin.mp.KoinPlatform

private typealias State = FeedContract.FeedState

@OptIn(ExperimentalCoroutinesApi::class)
class FeedViewModel(
    private val handle: SavedStateHandle,
    @Named("default") defaultDispatcher: CoroutineDispatcher
): ViewModel() {

    private var _uri: String? = null
    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            pager = null,
            refresh = false
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        viewModelScope.launch(defaultDispatcher) {
            (handle
                .getStateFlow<String?>("uri", null)
                .mapLatest { uri ->
                    updateState(uri)
                }
                    ).stateIn(this)
        }
    }

    fun updateState(
        uri: String? = _uri,
        refresh: Boolean = false
    ) {
        uri ?: return
        _state.update {
            it.copy(
                refresh = refresh
            )
        }
        try {
            Napier.d("setting pager")
            _state.update {
                it.copy(
                    pager = Pager(
                        PagingConfig(pageSize = 1), // not used
                        pagingSourceFactory = { FeedPaginator(uri, KoinPlatform.getKoin().get()) }
                    )
                        .flow
                        .cachedIn(viewModelScope)
                )
            }
        } finally {
            _state.update {
                it.copy(
                    refresh = false
                )
            }
        }
    }

}
