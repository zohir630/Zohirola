package dev.zohir.zohirola.ui.screens.image

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.navigation.toRoute
import dev.zohir.zohirola.ui.Route
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

private typealias State = ImageContract.ImageState

@OptIn(ExperimentalCoroutinesApi::class)
class ImageViewModel(
    private val handle: SavedStateHandle
): ViewModel() {

    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            images = null,
            fullsize = null,
            failedFullsize = emptySet(),
            idx = 0
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        val route = handle.toRoute<Route.Images>()
        _state.update {
            it.copy(
                images = route.images,
                fullsize = route.images.map { i -> i.replace("feed_thumbnail", "feed_fullsize") },
                idx = route.idx
            )
        }
    }

    fun fullsizeFailed(idx: Int) {
        _state.update {
            it.copy(failedFullsize = it.failedFullsize + idx)
        }
    }

    fun next() {
        if (_state.value.idx + 1 > (_state.value.images?.size ?: 0) - 1) return
        _state.update {
            it.copy(
                idx = it.idx + 1
            )
        }
    }

    fun previous() {
        if (_state.value.idx - 1 < 0) return
        _state.update {
            it.copy(
                idx = it.idx - 1
            )
        }
    }

}
