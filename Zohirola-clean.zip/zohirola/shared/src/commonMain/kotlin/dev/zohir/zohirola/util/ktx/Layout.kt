package dev.zohir.zohirola.util.ktx

enum class LayoutType {
    Compact,
    Wide
}

fun LayoutType.isWide() = this == LayoutType.Wide
