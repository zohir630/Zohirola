package dev.zohir.zohirola.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import dev.zohir.zohirola.paginators.SearchFeedsPaginator
import dev.zohir.zohirola.paginators.SearchPostsPaginator
import dev.zohir.zohirola.paginators.SearchProfilesPaginator
import dev.zohir.zohirola.repository.ZohirolaRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.Named

private typealias State = SearchContract.State

@OptIn(FlowPreview::class)
class SearchViewModel(
    private val zohirolaRepository: ZohirolaRepository,
    @Named("default") defaultDispatcher: CoroutineDispatcher
): ViewModel() {

    private val debouncedSearch = MutableStateFlow("")
    private var activeQuery: String? = null
    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            actorsPager = null,
            feedsPager = null,
            postsPager = null,
            tab = 0
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        viewModelScope.launch(defaultDispatcher) {
            debouncedSearch
                .debounce(500L)
                .collect { query ->
                    fetch(query)
                }
        }
    }

    fun search(
        query: String
    ) {
        debouncedSearch.value = query
    }

    private fun fetch(query: String) {
        if (query.isEmpty()) return
        if (query != activeQuery) {
            _state.update {
                it.copy(
                    actorsPager = null,
                    feedsPager = null,
                    postsPager = null
                )
            }
            activeQuery = query
        }
        setPager(_state.value.tab)
    }

    private fun setPager(
        idx: Int
    ) {
        val query = activeQuery ?: return
        val exists = when (idx) {
            0 -> _state.value.actorsPager != null
            1 -> _state.value.feedsPager != null
            else -> _state.value.postsPager != null
        }
        if (exists) return
        _state.update {
            when (idx) {
                0 -> it.copy(
                    actorsPager = Pager(
                        PagingConfig(pageSize = 1), // not used
                        pagingSourceFactory = { SearchProfilesPaginator(query, zohirolaRepository) }
                    )
                        .flow
                        .cachedIn(viewModelScope)
                )
                1 -> it.copy(
                    feedsPager = Pager(
                        PagingConfig(pageSize = 1), // not used
                        pagingSourceFactory = { SearchFeedsPaginator(query, zohirolaRepository) }
                    )
                        .flow
                        .cachedIn(viewModelScope)
                )
                else -> it.copy(
                    postsPager = Pager(
                        PagingConfig(pageSize = 1), // not used
                        pagingSourceFactory = { SearchPostsPaginator(query, zohirolaRepository) }
                    )
                        .flow
                        .cachedIn(viewModelScope)
                )
            }
        }
    }

    fun setTab(
        idx: Int
    ) {
        _state.update {
            it.copy(
                tab = idx
            )
        }
        if (debouncedSearch.value.isNotEmpty()) {
            setPager(idx)
        }
    }

}
