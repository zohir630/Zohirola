package dev.zohir.zohirola.ui.components.post

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.carousel.HorizontalMultiBrowseCarousel
import androidx.compose.material3.carousel.rememberCarouselState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import dev.zohir.zohirola.LocalInstanceInfo

private val ImageHeight = 256.dp
private val ImagePadding = 4.dp
private val RoundingRadius = 8.dp
private val ImageRoundingShape = RoundedCornerShape(RoundingRadius)

private fun calculateGridHeight(imageCount: Int) = when (imageCount) {
    1, 2 -> ImageHeight
    else -> (ImageHeight * 2) + ImagePadding
}

private fun calculateImageWidth(
    cardWidth: Dp,
    imageCount: Int
) = when (imageCount) {
    1 -> cardWidth - (ImagePadding * 2)
    else -> ((cardWidth / 2) - ImagePadding).coerceAtLeast(0.dp)
}

private fun calculateGridRounding(imageCount: Int): List<RoundedCornerShape> = when (imageCount) {
    1 -> listOf(ImageRoundingShape)
    2 -> listOf(
        RoundedCornerShape(
            topStart = RoundingRadius,
            bottomStart = RoundingRadius
        ),
        RoundedCornerShape(
            topEnd = RoundingRadius,
            bottomEnd = RoundingRadius
        )
    )
    3 -> listOf(
        RoundedCornerShape(
            topStart = RoundingRadius,
            bottomStart = RoundingRadius
        ),
        RoundedCornerShape(
            topEnd = RoundingRadius,
        ),
        RoundedCornerShape(
            bottomEnd = RoundingRadius
        )
    )
    else -> listOf(
        RoundedCornerShape(
            topStart = RoundingRadius,
        ),
        RoundedCornerShape(
            bottomStart = RoundingRadius
        ),
        RoundedCornerShape(
            topEnd = RoundingRadius,
        ),
        RoundedCornerShape(
            bottomEnd = RoundingRadius
        )
    )
}

@Composable
fun Images(
    images: List<String>,
    onClickImage: (Int) -> Unit
) {
    if (images.size > 4) {
        ImageCarousel(images, onClickImage)
    } else {
        ImageGrid(images, onClickImage)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageCarousel(
    images: List<String>,
    onClickImage: (Int) -> Unit
) {
    val instanceInfo = LocalInstanceInfo.current
    val configuration = LocalWindowInfo.current

    instanceInfo ?: return

    val count = remember { images.count() }

    val carouselState = rememberCarouselState { count }

    Box {
        HorizontalMultiBrowseCarousel(
            state = carouselState,
            preferredItemWidth = configuration.containerDpSize.width,
            itemSpacing = 8.dp,
            contentPadding = PaddingValues(ImagePadding),
            modifier = Modifier
                .height(ImageHeight)
                .fillMaxWidth()
        ) { idx ->
            val image = images[idx]
            AsyncImage(
                model = "${instanceInfo.fqdn}${image}",
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .maskClip(ImageRoundingShape)
                    .clickable {
                        onClickImage(idx)
                    }
            )
        }
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(start = ImagePadding * 2, top = ImagePadding * 2)
                .background(
                    Color.Black.copy(alpha = 0.5f),
                    RoundedCornerShape(RoundingRadius)
                )
        ) {
            Text(
                "${carouselState.currentItem + 1}/${count}",
                modifier = Modifier.padding(4.dp)
            )
        }
    }
}

@Composable
private fun ImageGrid(
    images: List<String>,
    onClickImage: (Int) -> Unit
) {
    val instanceInfo = LocalInstanceInfo.current
    val density = LocalDensity.current

    instanceInfo ?: return

    val columns = remember {
        when (images.size.coerceAtMost(4)) {
            1 -> 1
            else -> 2
        }
    }
    val cardWidth = remember { mutableStateOf(0) }
    val gridHeight = remember { calculateGridHeight(images.size) }
    val imageWidth = derivedStateOf {
        with(density) {
            calculateImageWidth(cardWidth.value.toDp(), images.size)
        }
    }
    val gridRounding = remember { calculateGridRounding(images.size) }

    LazyHorizontalGrid(
        GridCells.Fixed(columns),
        modifier = Modifier
            .height(gridHeight)
            .fillMaxWidth()
            .onGloballyPositioned {
                cardWidth.value = it.size.width
            },
        verticalArrangement = Arrangement.spacedBy(ImagePadding),
        horizontalArrangement = Arrangement.spacedBy(ImagePadding),
        contentPadding = PaddingValues(ImagePadding),
        userScrollEnabled = false
    ) {
        itemsIndexed(
            images,
            span = { idx, _ ->
                if ((images.size == 3 && idx == 0) ||
                    (images.size == 2 && (idx == 0 || idx == 1))) {
                    GridItemSpan(2)
                } else {
                    GridItemSpan(1)
                }
            }
        ) { idx, image ->
            AsyncImage(
                model = "${instanceInfo.fqdn}${image}",
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxHeight()
                    .width(imageWidth.value)
                    .clip(gridRounding[idx])
                    .clickable {
                        onClickImage(idx)
                    }
            )
        }
    }
}
