package dev.zohir.zohirola.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavDestination
import androidx.navigation.NavHostController
import androidx.navigation.toRoute
import kotlin.reflect.KClass

@Composable
expect fun BrowserHistorySync(authed: Boolean, navController: NavHostController)

fun NavHostController.navigateSyncable(route: Any) {
    when (route) {
        is Route.Profile -> navigate(route) { launchSingleTop = true }
        is Route.Post -> navigate(route) { launchSingleTop = true }
        is Route.Feed -> navigate(route) { launchSingleTop = true }
        is Route.BottomNavRoute.Home -> navigate(route) { launchSingleTop = true }
        is Route.BottomNavRoute.Search -> navigate(route) { launchSingleTop = true }
        is Route.BottomNavRoute.Following -> navigate(route) { launchSingleTop = true }
        is Route.BottomNavRoute.Saved -> navigate(route) { launchSingleTop = true }
    }
}

private fun NavDestination.hasRouteCompat(klass: KClass<*>) = NavDestination.run { hasRoute(klass) }

fun routeToHash(entry: NavBackStackEntry?): String? {
    val destination = entry?.destination ?: return null
    return when {
        destination.hasRouteCompat(Route.BottomNavRoute.Home::class) -> "/home"
        destination.hasRouteCompat(Route.BottomNavRoute.Search::class) -> "/search"
        destination.hasRouteCompat(Route.BottomNavRoute.Following::class) -> "/following"
        destination.hasRouteCompat(Route.BottomNavRoute.Saved::class) -> "/saved"
        destination.hasRouteCompat(Route.Profile::class) -> "/profile/${entry.toRoute<Route.Profile>().did}"
        destination.hasRouteCompat(Route.Post::class) -> {
            val route = entry.toRoute<Route.Post>()
            "/profile/${route.did}/post/${route.id}"
        }
        destination.hasRouteCompat(Route.Feed::class) -> "/feed/${percentEncode(entry.toRoute<Route.Feed>().uri)}"
        else -> null
    }
}

fun parseHash(hash: String): Any? {
    val path = hash.removePrefix("#").removePrefix("/")
    val segments = if (path.isEmpty()) emptyList() else path.split('/')
    return when (segments.size) {
        1 -> when (segments[0]) {
            "home" -> Route.BottomNavRoute.Home
            "search" -> Route.BottomNavRoute.Search
            "following" -> Route.BottomNavRoute.Following
            "saved" -> Route.BottomNavRoute.Saved
            else -> null
        }
        2 if segments[0] == "profile" -> Route.Profile(segments[1])
        4 if segments[0] == "profile" && segments[2] == "post" ->
            Route.Post(segments[1], segments[3])
        2 if segments[0] == "feed" ->
            percentDecode(segments[1])?.let { Route.Feed(it) }
        else -> null
    }
}

fun isPublicRoute(route: Any): Boolean = when (route) {
    is Route.Profile, is Route.Post, is Route.Feed, is Route.BottomNavRoute.Search -> true
    else -> false
}

fun percentEncode(value: String): String = buildString {
    for (byte in value.encodeToByteArray()) {
        val code = byte.toInt() and 0xFF
        val char = code.toChar()
        if (code < 0x80 && UNRESERVED.contains(char)) {
            append(char)
        } else {
            append('%')
            append(code.toString(16).uppercase().padStart(2, '0'))
        }
    }
}

fun percentDecode(value: String): String? {
    val bytes = ByteArray(value.length)
    var out = 0
    var i = 0
    while (i < value.length) {
        val char = value[i]
        if (char == '%') {
            if (i + 3 > value.length) return null
            val hex = value.substring(i + 1, i + 3)
            val byte = hex.toIntOrNull(16)?.toByte() ?: return null
            bytes[out++] = byte
            i += 3
        } else {
            val code = char.code
            if (code > 0x7F) return null
            bytes[out++] = code.toByte()
            i++
        }
    }
    return bytes.decodeToString(0, out)
}

private const val UNRESERVED = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
