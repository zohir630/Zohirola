package dev.zohir.zohirola.ui.components.post

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.AvatarImage
import dev.zohir.zohirola.ui.components.DefaultAvatarImageSize
import dev.zohir.zohirola.ui.components.ExternalEmbed
import dev.zohir.zohirola.ui.components.ParsedContent
import dev.zohir.zohirola.ui.components.Video
import dev.zohir.zohirola.util.ktx.horizontalContentPadding
import dev.zohir.zohirola.util.ktx.invisibleClickable
import dev.zohir.zohirola.util.ktx.noContent
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.at_handle
import zohirola.shared.generated.resources.baseline_chat_bubble_24
import zohirola.shared.generated.resources.baseline_favorite_24
import zohirola.shared.generated.resources.baseline_keep_24
import zohirola.shared.generated.resources.baseline_repeat_24
import zohirola.shared.generated.resources.could_not_auto_load_quoted_post
import zohirola.shared.generated.resources.day_unit
import zohirola.shared.generated.resources.hour_unit
import zohirola.shared.generated.resources.minute_unit
import zohirola.shared.generated.resources.now_lowercase
import zohirola.shared.generated.resources.pinned
import zohirola.shared.generated.resources.reposted_by
import zohirola.shared.generated.resources.view
import zohirola.shared.generated.resources.week_unit
import zohirola.shared.generated.resources.year_unit
import kotlin.time.Clock
import kotlin.time.Instant

@Composable
fun PostCard(
    post: Post,
    profileName: String?,
    onClickUri: (String) -> Unit
) {
    val navController = LocalNavController.current

    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .horizontalContentPadding()
            .invisibleClickable {
                navController.navigate(Route.Post(post.authorDid, post.id))
            }
    ) {
        Pin(post.pin)
        Repost(profileName, post.repost)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            AvatarImage(
                post.authorAvatar,
                padding = PaddingValues(0.dp, 4.dp, 4.dp,4.dp),
                onClick = {
                    navController.navigate(Route.Profile(post.authorHandle))
                }
            )
            Column(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    post.authorName?.let { authorName ->
                        Text(
                            if (authorName.length > 32) "${authorName.take(32)}..." else authorName,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Text(
                        stringResource(Res.string.at_handle, post.authorHandle),
                        maxLines = 1,
                        color = MaterialTheme.onSurfaceAlpha,
                        modifier = Modifier.weight(1f)
                    )
                    RelativeTime(post.createdAt)
                }
                ParsedContent(
                    post.content,
                    modifier = Modifier.fillMaxWidth(),
                    onClickHandle = { handle ->
                        navController.navigate(Route.Profile(handle))
                    },
                    onClickHashtag = {
                        // TODO
                    },
                    onClickUri = onClickUri
                )
                if (!post.images.isNullOrEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Images(
                        post.images,
                        onClickImage = { idx ->
                            navController.navigate(Route.Images(post.images, idx))
                        }
                    )
                }
                Video(post.playlist, post.playlistThumbnail)
                QuotedPost(post.quotedDid, post.quotedId)
                ExternalEmbed(post)
                InteractionRow(post)
            }
        }
    }
}

val PinRepostPadding = DefaultAvatarImageSize + 8.dp

@Composable
private fun Pin(
    pin: Boolean
) {
    if (pin) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = PinRepostPadding),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                painterResource(Res.drawable.baseline_keep_24),
                contentDescription = stringResource(Res.string.pinned),
                tint = MaterialTheme.onSurfaceAlpha,
                modifier = Modifier.size(14.dp)
            )
            Text(
                stringResource(Res.string.pinned),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.onSurfaceAlpha,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun Repost(
    profileName: String?,
    repost: Boolean
) {
    if (repost && profileName != null) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = PinRepostPadding),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                painterResource(Res.drawable.baseline_repeat_24),
                contentDescription = stringResource(Res.string.reposted_by, profileName),
                tint = MaterialTheme.onSurfaceAlpha,
                modifier = Modifier.size(14.dp)
            )
            Text(
                stringResource(Res.string.reposted_by, profileName),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.onSurfaceAlpha,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuotedPost(
    did: String?,
    id: String?
) {
    val navController = LocalNavController.current

    if (did != null && id != null) {
        Surface(
            Modifier
                .fillMaxWidth()
                .clickable {
                    navController.navigate(Route.Post(did, id))
                },
            color = MaterialTheme.noContent,
            shape = CardDefaults.shape
        ) {
            Row(
                Modifier.padding(vertical = 8.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    stringResource(Res.string.could_not_auto_load_quoted_post),
                    fontSize = 12.sp,
                    modifier = Modifier.weight(0.75f)
                )
                Text(
                    stringResource(Res.string.view),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(0.25f).fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

@Composable
private fun Video(
    playlist: String?,
    playlistThumbnail: String?
) {
    if (playlist != null) {
        Video(playlist)
    }
}

@Composable
private fun InteractionRow(
    post: Post
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Interaction(
            painterResource(Res.drawable.baseline_chat_bubble_24),
            post.replyCount
        )
        Interaction(
            painterResource(Res.drawable.baseline_repeat_24),
            post.quoteCount
        )
        Interaction(
            painterResource(Res.drawable.baseline_favorite_24),
            post.likeCount
        )
    }
}

@Composable
private fun RelativeTime(
    timestamp: String?
) {
    if (timestamp != null) {
        val relativeTime = remember {
            val diff = Clock.System.now().minus(Instant.parse("${timestamp}Z"))

            when {
                diff.inWholeDays >= 365 -> Pair(diff.inWholeDays / 365, Res.string.year_unit)
                diff.inWholeDays >= 7 -> Pair(diff.inWholeDays / 7, Res.string.week_unit)
                diff.inWholeDays >= 1 -> Pair(diff.inWholeDays, Res.string.day_unit)
                diff.inWholeHours     >= 1 -> Pair(diff.inWholeHours, Res.string.hour_unit)
                diff.inWholeMinutes   >= 1 -> Pair(diff.inWholeMinutes, Res.string.minute_unit)
                else -> null
            }
        }

        Text(
            if (relativeTime != null) stringResource(relativeTime.second, relativeTime.first) else stringResource(Res.string.now_lowercase),
            maxLines = 1,
            color = MaterialTheme.onSurfaceAlpha,
            textAlign = TextAlign.End
        )
    }
}
