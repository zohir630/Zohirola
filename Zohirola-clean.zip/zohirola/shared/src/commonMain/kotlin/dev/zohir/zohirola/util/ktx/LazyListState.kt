package dev.zohir.zohirola.util.ktx

import androidx.compose.foundation.lazy.LazyListState

suspend fun LazyListState.animateScrollToTop() = animateScrollToItem(0)
