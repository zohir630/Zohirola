package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.paginators.base.StringPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class SearchPostsPaginator(
    private val query: String,
    private val zohirolaRepository: ZohirolaRepository
): StringPagingSource<Post>() {

    override suspend fun fetchPage(cursor: String?): Pair<List<Post>, String?> {
        val response = zohirolaRepository.searchPosts(query, cursor)
        return response.posts to response.cursor
    }

}
