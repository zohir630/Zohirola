package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class InstanceInfo(
    val versionCode: Int? = 0,
    val registration: Boolean,
    val following: Boolean,
    val timelines: Boolean,
    val nsfw: Boolean
)
