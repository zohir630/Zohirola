package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Paginated<T>(
    val items: List<T>,
    val totalPages: Int
)
