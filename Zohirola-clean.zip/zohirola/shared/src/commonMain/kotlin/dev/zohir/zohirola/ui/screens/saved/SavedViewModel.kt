package dev.zohir.zohirola.ui.screens.saved

import androidx.lifecycle.ViewModel
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.paginators.SavedPostsPaginator
import kotlinx.coroutines.flow.Flow

class SavedViewModel(
    private val savedPostsPaginator: SavedPostsPaginator
): ViewModel() {

    val posts: Flow<PagingData<Post>> = Pager(
        config = PagingConfig(pageSize = 1), // page size not used
        pagingSourceFactory = { savedPostsPaginator }
    ).flow

}
