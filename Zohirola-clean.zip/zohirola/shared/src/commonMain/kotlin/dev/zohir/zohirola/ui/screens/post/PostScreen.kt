package dev.zohir.zohirola.ui.screens.post

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Reply
import dev.zohir.zohirola.data.model.response.ReplyPost
import dev.zohir.zohirola.data.model.response.takeFirst
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.AvatarImage
import dev.zohir.zohirola.ui.components.ExternalEmbed
import dev.zohir.zohirola.ui.components.ParsedContent
import dev.zohir.zohirola.ui.components.ShareSheet
import dev.zohir.zohirola.ui.components.Video
import dev.zohir.zohirola.ui.components.buttons.BackButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.tryAgain
import dev.zohir.zohirola.ui.components.post.Images
import dev.zohir.zohirola.ui.components.post.Interaction
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.conditional
import dev.zohir.zohirola.util.ktx.format
import dev.zohir.zohirola.util.ktx.invisibleClickable
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import kotlinx.coroutines.launch
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.format
import kotlinx.datetime.format.MonthNames
import kotlinx.datetime.format.char
import kotlinx.datetime.toLocalDateTime
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.at_handle
import zohirola.shared.generated.resources.baseline_bookmark_24
import zohirola.shared.generated.resources.baseline_bookmark_added_24
import zohirola.shared.generated.resources.baseline_chat_bubble_24
import zohirola.shared.generated.resources.baseline_favorite_24
import zohirola.shared.generated.resources.baseline_repeat_24
import zohirola.shared.generated.resources.baseline_share_24
import zohirola.shared.generated.resources.likes_lowercase
import zohirola.shared.generated.resources.quotes_lowercase
import kotlin.time.Instant

@Composable
fun PostScreen(
    viewModel: PostViewModel = koinViewModel()
) {
    val scope = rememberCoroutineScope()
    val state by viewModel.state.collectAsStateWithLifecycle()

    val uri = remember { mutableStateOf<String?>(null) }
    val shareSheetUri = remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            BackButton()
        }
    ) { padding ->
        AdaptiveLazyColumn(
            padding
        ) {
            state.post?.let { post ->
                item {
                    PostItem(
                        post,
                        state.isSaved,
                        onClickUri = {
                            uri.value = it
                        },
                        onClickSave = {
                            if (state.isSaved == true) {
                                scope.launch {
                                    viewModel.unsave(post.authorDid, post.cid, child = false)
                                }
                            } else {
                                scope.launch {
                                    viewModel.save(post.authorDid, post.id, child = false)
                                }
                            }
                        },
                        onShare = {
                            shareSheetUri.value = "/profile/${post.authorHandle}/post/${post.id}"
                        }
                    )
                }
            }
            state.replies?.let { replies ->
                itemsWithDivider(replies) { reply ->
                    ReplyItem(
                        reply,
                        onClickUri = {
                            uri.value = it
                        },
                        onClickSave = {
                            scope.launch {
                                viewModel.save(reply.post.author.did, reply.post.id, child = true)
                            }
                        },
                        onShare = {
                            shareSheetUri.value = "/profile/${reply.post.author.handle}/post/${reply.post.id}"
                        }
                    )
                }
            }
            state.error?.let { error ->
                tryAgain(
                    error.message,
                    onClick = {
                        scope.launch {
                            viewModel.getPost()
                        }
                    }
                )
            }
        }
        UriDialog(
            uri.value,
            onDismissRequest = {
                uri.value = null
            }
        )
        ShareSheet(
            shareSheetUri.value,
            onDismissRequest = {
                shareSheetUri.value = null
            }
        )
    }
}

@Composable
private fun PostItem(
    post: Post,
    isSaved: Boolean?,
    onClickUri: (String) -> Unit,
    onClickSave: () -> Unit,
    onShare: () -> Unit
) {
    val navController = LocalNavController.current

    val datetime = remember {
        if (post.createdAt != null) {
            Instant
                .parse("${post.createdAt}Z")
                .toLocalDateTime(TimeZone.currentSystemDefault())
                .format(
                    LocalDateTime.Format {
                        hour()
                        char(':')
                        minute()
                        chars(" · ")
                        monthName(MonthNames.ENGLISH_ABBREVIATED)
                        char(' ')
                        day()
                        chars(", ")
                        year()
                    }
                )
        } else {
            null
        }
    }

    Column(
        Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AvatarImage(
                post.authorAvatar,
                onClick = {
                    navController.navigate(Route.Profile(post.authorDid))
                }
            )
            Column(
                Modifier.invisibleClickable {
                    navController.navigate(Route.Profile(post.authorDid))
                }
            ) {
                post.authorName?.let { authorName ->
                    Text(
                        authorName,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    stringResource(Res.string.at_handle, post.authorHandle),
                    color = MaterialTheme.onSurfaceAlpha,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        ParsedContent(
            post.content,
            onClickHandle = { handle ->
                navController.navigate(Route.Profile(handle))
            },
            onClickHashtag = {
                // TODO
            },
            onClickUri = onClickUri,
        )
        if (!post.images.isNullOrEmpty()) {
            Images(
                post.images,
                onClickImage = { idx ->
                    navController.navigate(Route.Images(post.images, idx))
                }
            )
        }
        if (!post.playlist.isNullOrEmpty()) {
            Video(post.playlist)
        }
        ExternalEmbed(post)
        Text(
            datetime.toString(),
            color = MaterialTheme.onSurfaceAlpha
        )
        HorizontalDivider()
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InteractionText(post.quoteCount, Res.string.quotes_lowercase)
            // TODO in backend add repost count
            InteractionText(post.likeCount, Res.string.likes_lowercase)
        }
        HorizontalDivider()
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Interaction(
                painterResource(Res.drawable.baseline_chat_bubble_24),
                post.replyCount
            )
            Interaction(
                painterResource(Res.drawable.baseline_repeat_24),
                post.quoteCount
            )
            Interaction(
                painterResource(Res.drawable.baseline_favorite_24),
                post.likeCount
            )
            Spacer(Modifier.weight(1f))
            CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides 0.dp) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            onClickSave()
                        },
                        enabled = isSaved != null,
                        modifier = Modifier.size(20.dp)
                    ) {
                        when (isSaved) {
                            true -> Icon(
                                painterResource(Res.drawable.baseline_bookmark_added_24),
                                contentDescription = null,
                                tint = MaterialTheme.onSurfaceAlpha
                            )
                            false -> Icon(
                                painterResource(Res.drawable.baseline_bookmark_24),
                                contentDescription = null,
                                tint = MaterialTheme.onSurfaceAlpha
                            )
                            null -> CircularProgressIndicator(Modifier.size(24.dp))
                        }
                    }
                    IconButton(
                        onClick = {
                            onShare()
                        },
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            painterResource(Res.drawable.baseline_share_24),
                            contentDescription = null,
                            tint = MaterialTheme.onSurfaceAlpha
                        )
                    }
                }
            }
        }
        HorizontalDivider()
    }
}

@Composable
private fun InteractionText(
    number: Int?,
    resource: StringResource
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text((number ?: 0).format())
        Text(
            stringResource(resource),
            color = MaterialTheme.onSurfaceAlpha
        )
    }
}

val ReplyAvatarSize = 36.dp

@Composable
private fun ReplyItem(
    reply: Reply,
    onClickUri: (String) -> Unit,
    onClickSave: () -> Unit,
    onShare: () -> Unit
) {
    val lastItemOffset = remember { mutableStateOf<Offset?>(null) }

    Column {
        ReplyPostItem(
            reply.post,
            onClickUri = onClickUri,
            onClickSave = onClickSave,
            onShare = onShare,
            lineEnd = lastItemOffset.value
        )
        if (!reply.replies.isNullOrEmpty()) {
            val replyPostItems = remember { reply.takeFirst() }
            replyPostItems.forEachIndexed { idx, post ->
                ReplyPostItem(
                    post,
                    onClickUri = onClickUri,
                    onClickSave = onClickSave,
                    onShare = onShare,
                    onPositioned = if (idx == replyPostItems.size - 1) {
                        {
                            lastItemOffset.value = it
                        }
                    } else {
                        null
                    }
                )
            }
        }
    }
}

@Composable
private fun ReplyPostItem(
    post: ReplyPost,
    onClickUri: (String) -> Unit,
    onClickSave: () -> Unit,
    onShare: () -> Unit,
    lineEnd: Offset? = null,
    onPositioned: ((Offset) -> Unit)? = null
) {
    val navController = LocalNavController.current

    val onSurfaceAlpha = MaterialTheme.onSurfaceAlpha

    val replyAvatarSizeRadiusPx = with(LocalDensity.current) {
        ReplyAvatarSize.toPx() / 2
    }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .invisibleClickable {
                navController.navigate(Route.Post(post.author.did, post.id))
            }
            .conditional(onPositioned != null) {
                onPlaced { coords ->
                    onPositioned?.invoke(coords.positionInParent())
                }
            },
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier
                .wrapContentSize()
                .conditional(lineEnd != null) {
                    drawWithCache {
                        onDrawBehind {
                            drawLine(
                                start = Offset(replyAvatarSizeRadiusPx, replyAvatarSizeRadiusPx),
                                end = Offset(replyAvatarSizeRadiusPx, lineEnd?.y ?: (replyAvatarSizeRadiusPx)),
                                color = onSurfaceAlpha,
                                strokeWidth = 6.dp.value
                            )
                        }
                    }
                }
        ) {
            AvatarImage(
                post.author.avatar,
                size = ReplyAvatarSize,
                padding = PaddingValues(top = 4.dp),
                backgroundRadius = replyAvatarSizeRadiusPx + 12f,
                onClick = {
                    navController.navigate(Route.Profile(post.author.did))
                }
            )
        }
        Column {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                post.author.displayName?.let { displayName ->
                    Text(
                        displayName,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    stringResource(Res.string.at_handle, post.author.handle),
                    color = MaterialTheme.onSurfaceAlpha,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                // TODO time
            }
            ParsedContent(
                post.record.text,
                onClickHandle = { handle ->
                    navController.navigate(Route.Profile(handle))
                },
                onClickHashtag = {
                    // TODO
                },
                onClickUri = onClickUri,
            )
            Spacer(Modifier.height(4.dp))
            if (!post.embed?.images.isNullOrEmpty()) {
                val images = remember { post.embed.images.map { it.thumb } }
                Images(
                    images,
                    onClickImage = { idx ->
                        navController.navigate(Route.Images(images, idx))
                    }
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Interaction(
                    painterResource(Res.drawable.baseline_chat_bubble_24),
                    post.replyCount
                )
                Interaction(
                    painterResource(Res.drawable.baseline_repeat_24),
                    post.quoteCount
                )
                Interaction(
                    painterResource(Res.drawable.baseline_favorite_24),
                    post.likeCount
                )
                Spacer(Modifier.weight(1f))
                CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides 0.dp) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = {
                                onClickSave()
                            },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                painterResource(Res.drawable.baseline_bookmark_24),
                                contentDescription = null,
                                tint = MaterialTheme.onSurfaceAlpha
                            )
                        }
                        IconButton(
                            onClick = {
                                onShare()
                            },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                painterResource(Res.drawable.baseline_share_24),
                                contentDescription = null,
                                tint = MaterialTheme.onSurfaceAlpha
                            )
                        }
                    }
                }
            }
        }
    }
}
