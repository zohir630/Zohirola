package dev.zohir.zohirola.plugins

import de.jensklingenberg.ktorfit.annotations
import dev.zohir.zohirola.repository.StoreRepository
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.http.set

private val SCHEME_REGEX = "http(s)?://".toRegex()
private val PORT_REGEX = ":\\d+".toRegex()

class InstancePluginConfig {
    var storeRepository: Lazy<StoreRepository>? = null
}

val InstancePlugin = createClientPlugin(
    "InstancePlugin",
    ::InstancePluginConfig
) {
    onRequest { request, _ ->
        if (request.annotations.filterIsInstance<Passthrough>().isNotEmpty()) return@onRequest
        val fqdn = this@createClientPlugin.pluginConfig.storeRepository?.value?.getInstanceFQDN() ?: return@onRequest
        val scheme = if (fqdn.startsWith("https")) "https" else "http"
        val host = fqdn
            .replace(SCHEME_REGEX, "")
            .replace(PORT_REGEX, "")
        val port = try {
            fqdn.split(":").lastOrNull()?.toInt() ?: if (scheme == "https") 443 else 80
        } catch (_: Exception) {
            if (scheme == "https") 443 else 80
        }
        request.url.set(scheme, host, port)
    }
}
