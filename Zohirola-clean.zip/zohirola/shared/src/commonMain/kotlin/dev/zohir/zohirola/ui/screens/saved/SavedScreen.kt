package dev.zohir.zohirola.ui.screens.saved

import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.TopBar
import dev.zohir.zohirola.ui.components.buttons.ScrollToTopButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.pagerEmptyItem
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.ui.components.post.PostCard
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.animateScrollToTop
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.no_saved_posts
import zohirola.shared.generated.resources.saved

@Composable
fun SavedScreen(
    viewModel: SavedViewModel = koinViewModel()
) {
    val posts = viewModel.posts.collectAsLazyPagingItems()

    val scope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    val uri = remember { mutableStateOf<String?>(null) }

    val showScrollFab by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex > 0
        }
    }

    PullToRefreshBox(
        posts.loadState.refresh == LoadState.Loading,
        onRefresh = posts::refresh
    ) {
        Scaffold(
            topBar = {
                TopBar(
                    title = {
                        Text(stringResource(Res.string.saved))
                    }
                )
            },
            floatingActionButton = {
                ScrollToTopButton(showScrollFab) { scope.launch { lazyListState.animateScrollToTop() } }
            }
        ) { padding ->
            AdaptiveLazyColumn(
                insets = padding,
                state = lazyListState
            ) {
                pagerEmptyItem(posts, Res.string.no_saved_posts)
                itemsWithDivider(posts.itemCount) { idx ->
                    val post = posts[idx] ?: return@itemsWithDivider
                    PostCard(
                        post,
                        null,
                        onClickUri = {
                            uri.value = it
                        }
                    )
                }
                pagerStateItem(posts)
            }
            UriDialog(
                uri.value,
                onDismissRequest = {
                    uri.value = null
                }
            )
        }
    }
}
