package dev.zohir.zohirola.data

import androidx.compose.material3.SnackbarDuration
import org.jetbrains.compose.resources.StringResource

sealed class Event

class RequiresAuth: Event()

class AuthExpired: Event()

class Custom(
    val string: String?,
    val dismissable: Boolean = true,
    val duration: SnackbarDuration = SnackbarDuration.Long
): Event()

class CustomResource(
    val resource: StringResource,
    val parameters: Array<out Any> = arrayOf(),
    val dismissable: Boolean = true,
    val duration: SnackbarDuration = SnackbarDuration.Long
): Event()
