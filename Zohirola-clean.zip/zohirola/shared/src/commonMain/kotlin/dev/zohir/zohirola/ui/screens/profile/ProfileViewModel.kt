package dev.zohir.zohirola.ui.screens.profile

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import dev.zohir.zohirola.data.model.response.ResponseError
import dev.zohir.zohirola.data.model.response.ServiceUnavailable
import dev.zohir.zohirola.paginators.PostsPaginator
import dev.zohir.zohirola.repository.ZohirolaRepository
import io.github.aakira.napier.Napier
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.annotation.Named
import org.koin.mp.KoinPlatform

private typealias State = ProfileContract.ProfileState

@OptIn(ExperimentalCoroutinesApi::class)
class ProfileViewModel(
    private val handle: SavedStateHandle,
    private val zohirolaRepository: ZohirolaRepository,
    @Named("default") defaultDispatcher: CoroutineDispatcher,
    @Named("io") private val ioDispatcher: CoroutineDispatcher
): ViewModel() {

    private var _did: String? = null
    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            profile = null,
            pager = null,
            error = null,
            followUpdateLoading = false,
            refresh = false
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        viewModelScope.launch(defaultDispatcher) {
            (handle
                .getStateFlow<String?>("did", null)
                .mapLatest { did ->
                    if (this@ProfileViewModel._did != did) {
                        this@ProfileViewModel._did = did
                        if (did == null) return@mapLatest
                        updateState(did)
                    }
                }
            ).stateIn(this)
        }
    }

    suspend fun updateState(
        did: String,
        refresh: Boolean = false
    ) {
        _state.update {
            it.copy(
                refresh = refresh
            )
        }
        try {
            getProfile(did)
            _state.update {
                it.copy(
                    pager = Pager(
                        PagingConfig(pageSize = 1), // not used
                        pagingSourceFactory = { PostsPaginator(did, KoinPlatform.getKoin().get()) }
                    )
                        .flow
                        .cachedIn(viewModelScope)
                )
            }
        } finally {
            _state.update {
                it.copy(
                    refresh = false
                )
            }
        }
    }

    suspend fun getProfile(
        did: String? = _did
    ) = withContext(ioDispatcher) {
        did ?: return@withContext
        _state.update {
            it.copy(
                profile = null,
                error = null
            )
        }
        try {
            _state.update {
                it.copy(
                    profile = zohirolaRepository.getProfile(did)
                )
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(error = e.error)
            }
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            _state.update {
                it.copy(error = ServiceUnavailable(e.message.toString()))
            }
        }
    }

    suspend fun follow(
        did: String,
    ) = withContext(ioDispatcher) {
        _state.update {
            it.copy(
                followUpdateLoading = true,
            )
        }
        try {
            zohirolaRepository.follow(did)
            _state.update {
                it.copy(
                    profile = zohirolaRepository.getProfile(did),
                    followUpdateLoading = false
                )
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(
                    error = e.error,
                    followUpdateLoading = false
                )
            }
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            _state.update {
                it.copy(
                    error = ServiceUnavailable(e.message.toString()),
                    followUpdateLoading = false
                )
            }
        }
    }

    suspend fun unfollow(
        did: String,
    ) = withContext(ioDispatcher) {
        _state.update {
            it.copy(
                followUpdateLoading = true,
            )
        }
        try {
            zohirolaRepository.unfollow(did)
            _state.update {
                it.copy(
                    profile = zohirolaRepository.getProfile(did),
                    followUpdateLoading = false
                )
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(
                    error = e.error,
                    followUpdateLoading = false
                )
            }
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            _state.update {
                it.copy(
                    error = ServiceUnavailable(e.message.toString()),
                    followUpdateLoading = false
                )
            }
        }
    }

}
