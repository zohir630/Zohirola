package dev.zohir.zohirola.data.model.response.profile

import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Reply
import kotlinx.serialization.Serializable

@Serializable
data class PostResponse(
    val postReplies: PostWithReplies,
    val isSaved: Boolean? = false
)

@Serializable
data class PostWithReplies(
    val post: Post,
    val replies: List<Reply>
)
