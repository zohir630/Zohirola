package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.LocalLayoutType
import dev.zohir.zohirola.util.ktx.isWide

@Composable
fun AdaptiveBox(
    insets: PaddingValues,
    content: @Composable (edgePadding: PaddingValues) -> Unit
) {
    val layoutType = LocalLayoutType.current

    BoxWithConstraints(
        Modifier.padding(insets)
    ) {
        val edgePadding = if (layoutType.isWide()) {
            this.maxWidth * 0.15f
        } else {
            0.dp
        }

        content(PaddingValues(horizontal = edgePadding))
    }
}

@Composable
fun AdaptiveLazyColumn(
    insets: PaddingValues,
    contentPadding: Dp = 12.dp,
    state: LazyListState = rememberLazyListState(),
    content: LazyListScope.() -> Unit
) {
    AdaptiveBox(insets) { edgePadding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(horizontal = contentPadding)
                .padding(bottom = 8.dp),
            state = state,
            contentPadding = edgePadding
        ) {
            content()
        }
    }
}
