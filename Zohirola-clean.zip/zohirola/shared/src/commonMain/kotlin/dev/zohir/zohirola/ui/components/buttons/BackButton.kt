package dev.zohir.zohirola.ui.components.buttons

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import dev.zohir.zohirola.LocalNavController
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_arrow_back_24
import zohirola.shared.generated.resources.go_back

@Composable
fun BackButton(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val navController = LocalNavController.current

    IconButton(
        onClick = {
            if (onClick != null) {
                onClick()
            } else {
                navController.popBackStack()
            }
        },
        modifier = modifier
    ) {
        Icon(
            painterResource(Res.drawable.baseline_arrow_back_24),
            contentDescription = stringResource(Res.string.go_back)
        )
    }
}

@Composable
fun BackButtonBox(
    onClick: (() -> Unit)? = null
) {
    Box(
        Modifier
            .fillMaxSize()
            .zIndex(1f)
    ) {
        BackButton(
            Modifier.align(Alignment.TopStart),
            onClick = onClick
        )
    }
}
