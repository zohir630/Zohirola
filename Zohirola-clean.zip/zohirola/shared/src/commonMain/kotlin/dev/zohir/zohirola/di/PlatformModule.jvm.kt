package dev.zohir.zohirola.di

import org.koin.core.module.Module

expect fun platformModule(): Module
