package dev.zohir.zohirola.repository

import dev.zohir.zohirola.data.AuthExpired
import dev.zohir.zohirola.data.Custom
import dev.zohir.zohirola.data.CustomResource
import dev.zohir.zohirola.data.Event
import dev.zohir.zohirola.data.RequiresAuth
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow

interface EventBusRepository {
    val bus: Flow<Event>

    suspend fun requiresAuth()
    suspend fun authExpired()
    suspend fun custom(event: Custom)
    suspend fun customResource(event: CustomResource)
}

class EventBusRepositoryImpl: EventBusRepository {
    private val _bus: Channel<Event> = Channel(Channel.UNLIMITED)
    override val bus: Flow<Event>
        get() = _bus.receiveAsFlow()

    private suspend fun emit(event: Event) = _bus.send(event)

    override suspend fun requiresAuth() {
        emit(RequiresAuth())
    }

    override suspend fun authExpired() {
        emit(AuthExpired())
    }

    override suspend fun custom(event: Custom) {
        emit(event)
    }

    override suspend fun customResource(event: CustomResource) {
        emit(event)
    }
}
