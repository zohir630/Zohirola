package dev.zohir.zohirola.di

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import org.koin.core.qualifier.named
import org.koin.dsl.module

object DispatchersModule {
    val dispatchersModule = module {
        single<CoroutineDispatcher>(named("default")) { Dispatchers.Default }
    }
}
