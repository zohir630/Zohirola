package dev.zohir.zohirola.paginators.base

import androidx.paging.PagingSource
import androidx.paging.PagingState

abstract class IntegerPagingSource<T: Any>: PagingSource<Int, T>() {

    protected abstract suspend fun fetchPage(page: Int): List<T>

    final override suspend fun load(params: LoadParams<Int>): LoadResult<Int, T> {
        return try {
            val page = params.key ?: 1
            val items = fetchPage(page)

            LoadResult.Page(
                data = items,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (items.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    final override fun getRefreshKey(state: PagingState<Int, T>): Int? = state.anchorPosition?.let { anchor ->
        val page = state.closestPageToPosition(anchor)
        page?.prevKey?.plus(1) ?: page?.nextKey?.minus(1)
    }

}
