package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Reply(
    val post: ReplyPost,
    val replies: List<Reply>?
)

@Serializable
data class ReplyPost(
    val uri: String,
    val cid: String,
    val author: ReplyAuthor,
    val record: ReplyRecord,
    val embed: ReplyEmbed?,
    val likeCount: Int?,
    val replyCount: Int?,
    val quoteCount: Int?,
    val indexedAt: String
) {
    val id = uri.split("/").last()
}

@Serializable
data class ReplyAuthor(
    val did: String,
    val handle: String,
    val displayName: String?,
    val avatar: String?
)

@Serializable
data class ReplyRecord(
    val text: String
)

@Serializable
data class ReplyEmbed(
    val images: List<ReplyImage>?,
    val playlist: String?,
    val thumbnail: String? // playlistThumbnail
)

@Serializable
data class ReplyImage(
    val thumb: String
)

// In a thread of replies, always take the first reply and iterate on that reply
fun Reply.takeFirst(): List<ReplyPost> {
    val posts = mutableListOf<ReplyPost>()
    var current = this
    while (!current.replies.isNullOrEmpty()) {
        val next = current.replies.first()
        posts.add(next.post)
        current = next
    }
    return posts.toList()
}
