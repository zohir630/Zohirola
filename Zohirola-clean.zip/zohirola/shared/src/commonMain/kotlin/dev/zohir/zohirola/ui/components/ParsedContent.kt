package dev.zohir.zohirola.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withLink
import dev.zohir.zohirola.util.ktx.highlightedText

@Composable
fun ParsedContent(
    text: String?,
    onClickHandle: (String) -> Unit,
    onClickHashtag: (String) -> Unit,
    onClickUri: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    text ?: return

    val highlightColor = MaterialTheme.colorScheme.primary

    val highlightRegex = remember {
        """(?<handle>@\S+)|(?<hashtag>#\S+)|(?<link>\[(?<text>[^]]+)]\((?<scheme>http(s)?://)(?<uri>\S*)\))"""
            .toRegex(RegexOption.IGNORE_CASE)
    }
    val linkRegex = remember {
        """\[(?<text>[^]]+)]\((?<scheme>http(s)?://)(?<uri>\S*)\)"""
            .toRegex(RegexOption.IGNORE_CASE)
    }

    val annotated = remember {
        buildAnnotatedString {
            var cursor = 0
            highlightRegex.findAll(text).forEach { match ->
                if (match.range.first > cursor) {
                    append(text.substring(cursor, match.range.first))
                }

                when {
                    match.groups["handle"] != null -> {
                        withLink(
                            link = LinkAnnotation.Clickable(
                                tag = "handle",
                                linkInteractionListener = {
                                    onClickHandle(match.value.dropWhile { c -> c == '@' })
                                }
                            )
                        ) {
                            highlightedText(match.value, highlightColor)
                        }
                    }
                    match.groups["hashtag"] != null -> {
                        withLink(
                            link = LinkAnnotation.Clickable(
                                tag = "hashtag",
                                linkInteractionListener = {
                                    onClickHashtag(match.value.dropWhile { c -> c == '#' })
                                }
                            )
                        ) {
                            highlightedText(match.value, highlightColor)
                        }
                    }
                    match.groups["link"] != null -> {
                        linkRegex.find(match.value)?.groups?.let { groups ->
                            val text = groups["text"]?.value
                            val scheme = groups["scheme"]?.value
                            val uri = groups["uri"]?.value
                            if (text != null && scheme != null && uri != null) {
                                withLink(
                                    link = LinkAnnotation.Clickable(
                                        tag = "uri",
                                        linkInteractionListener = {
                                            onClickUri("${scheme}${uri}")
                                        }
                                    )
                                ) {
                                    highlightedText(text, highlightColor)
                                }
                            }
                        }
                    }
                }

                cursor = match.range.last + 1
            }

            if (cursor < text.length) {
                append(text.substring(cursor))
            }
        }
    }

    Text(
        annotated,
        modifier = modifier
    )
}
