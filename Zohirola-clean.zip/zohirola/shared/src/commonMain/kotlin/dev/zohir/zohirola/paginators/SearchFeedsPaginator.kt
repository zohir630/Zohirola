package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.Feed
import dev.zohir.zohirola.paginators.base.StringPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class SearchFeedsPaginator(
    private val query: String,
    private val zohirolaRepository: ZohirolaRepository
): StringPagingSource<Feed>() {

    override suspend fun fetchPage(cursor: String?): Pair<List<Feed>, String?> {
        val response = zohirolaRepository.searchFeeds(query, cursor)
        return response.feeds to response.cursor
    }

}
