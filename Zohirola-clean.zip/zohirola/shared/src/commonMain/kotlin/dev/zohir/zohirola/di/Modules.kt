package dev.zohir.zohirola.di

import org.koin.core.KoinApplication

fun KoinApplication.installModules() {
    modules(
        platformModule(),
        AppModule.appModule,
        DispatchersModule.dispatchersModule,
        RepositoryModule.repositoryModule,
        NetworkModule.networkModule,
        ViewModelModule.viewModelModule,
        PaginatorModule.paginatorModule
    )
}
