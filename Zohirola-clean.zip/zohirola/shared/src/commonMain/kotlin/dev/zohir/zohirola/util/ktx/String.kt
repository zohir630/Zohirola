package dev.zohir.zohirola.util.ktx

import androidx.compose.ui.platform.ClipEntry

expect fun String.toClipEntry(): ClipEntry
