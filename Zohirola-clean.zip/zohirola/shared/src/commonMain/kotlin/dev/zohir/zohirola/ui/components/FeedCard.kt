package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.data.model.response.Feed
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.at_handle

@Composable
fun FeedCard(
    feed: Feed,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            }
            .padding(vertical = (2.5).dp)
            .padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AvatarImage(feed.avatar)
        Column {
            feed.displayName?.let { displayName ->
                Text(
                    displayName,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                stringResource(Res.string.at_handle, feed.creator.handle),
                color = MaterialTheme.onSurfaceAlpha,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}
