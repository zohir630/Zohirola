package dev.zohir.zohirola.ui.screens.profile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.paging.compose.collectAsLazyPagingItems
import coil3.compose.AsyncImage
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.ParsedContent
import dev.zohir.zohirola.ui.components.ShareSheet
import dev.zohir.zohirola.ui.components.buttons.BackButtonBox
import dev.zohir.zohirola.ui.components.buttons.IconTextButton
import dev.zohir.zohirola.ui.components.buttons.LoadingTextButton
import dev.zohir.zohirola.ui.components.buttons.OutlinedIconTextButton
import dev.zohir.zohirola.ui.components.buttons.ScrollToTopButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.loading
import dev.zohir.zohirola.ui.components.lazy.pagerEmptyItem
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.ui.components.lazy.tryAgain
import dev.zohir.zohirola.ui.components.post.PostCard
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.animateScrollToTop
import dev.zohir.zohirola.util.ktx.format
import dev.zohir.zohirola.util.ktx.horizontalContentPadding
import dev.zohir.zohirola.util.ktx.invisibleClickable
import dev.zohir.zohirola.util.ktx.noContent
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.at_handle
import zohirola.shared.generated.resources.baseline_add_24
import zohirola.shared.generated.resources.baseline_check_24
import zohirola.shared.generated.resources.baseline_share_24
import zohirola.shared.generated.resources.follow
import zohirola.shared.generated.resources.followers_lowercase
import zohirola.shared.generated.resources.following_lowercase
import zohirola.shared.generated.resources.no_posts
import zohirola.shared.generated.resources.posts_lowercase
import zohirola.shared.generated.resources.share
import zohirola.shared.generated.resources.unfollow

val BannerHeight = 196.dp

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel = koinViewModel()
) {
    val navController = LocalNavController.current
    val instanceInfo = LocalInstanceInfo.current

    instanceInfo ?: return

    val state = viewModel.state.collectAsStateWithLifecycle().value
    val posts = state.pager?.collectAsLazyPagingItems()

    val scope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    val uri = remember { mutableStateOf<String?>(null) }
    val shareSheetUri = remember { mutableStateOf<String?>(null) }

    val showScrollFab by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex > 0
        }
    }

    PullToRefreshBox(
        state.refresh,
        onRefresh = {
            state.profile?.did?.let { did ->
                scope.launch {
                    viewModel.updateState(did, refresh = true)
                }
            }
        }
    ) {
        Scaffold(
            floatingActionButton = {
                ScrollToTopButton(showScrollFab) {
                    scope.launch {
                        lazyListState.animateScrollToTop()
                    }
                }
            }
        ) { padding ->
            AdaptiveLazyColumn(
                padding,
                contentPadding = 0.dp,
                state = lazyListState
            ) {
                when {
                    state.profile == null && state.error == null -> loading()
                    state.profile == null && state.error != null -> tryAgain(
                        state.error.message,
                        onClick = {
                            scope.launch {
                                viewModel.getProfile()
                            }
                        }
                    )
                    state.profile != null -> {
                        item {
                            with(state.profile) {
                                Column(
                                    Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (banner != null) {
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .height(BannerHeight)
                                        ) {
                                            BackButtonBox()
                                            ShareButtonBox {
                                                shareSheetUri.value = "/profile/${id}"
                                            }
                                            Box(
                                                Modifier.wrapContentSize()
                                            ) {
                                                AsyncImage(
                                                    model = "${instanceInfo.fqdn}${banner}",
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(BannerHeight)
                                                        .invisibleClickable {
                                                            navController.navigate(Route.Images(listOf(banner), 0))
                                                        }
                                                )
                                            }
                                            Avatar(avatar)
                                        }
                                    } else {
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .height(BannerHeight)
                                                .background(MaterialTheme.noContent)
                                        ) {
                                            BackButtonBox()
                                            ShareButtonBox {
                                                shareSheetUri.value = "/profile/${id}"
                                            }
                                            Avatar(avatar)
                                        }
                                    }
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(end = 12.dp),
                                        contentAlignment = Alignment.CenterEnd
                                    ) {
                                        if (state.followUpdateLoading) {
                                            if (state.profile.isFollowing == true) {
                                                LoadingTextButton(
                                                    text = stringResource(Res.string.unfollow)
                                                )
                                            } else {
                                                LoadingTextButton(
                                                    text = stringResource(Res.string.follow)
                                                )
                                            }
                                        } else {
                                            if (state.profile.isFollowing == true) {
                                                OutlinedIconTextButton(
                                                    icon = painterResource(Res.drawable.baseline_check_24),
                                                    text = stringResource(Res.string.unfollow),
                                                    onClick = {
                                                        scope.launch {
                                                            viewModel.unfollow(did)
                                                        }
                                                    }
                                                )
                                            } else {
                                                IconTextButton(
                                                    icon = painterResource(Res.drawable.baseline_add_24),
                                                    text = stringResource(Res.string.follow),
                                                    onClick = {
                                                        scope.launch {
                                                            viewModel.follow(did)
                                                        }
                                                    },
                                                    enabled = instanceInfo.following
                                                )
                                            }
                                        }
                                    }
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .horizontalContentPadding()
                                    ) {
                                        Column(
                                            Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                name,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                stringResource(Res.string.at_handle, id),
                                                color = MaterialTheme.onSurfaceAlpha
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text(
                                                        followers.format(),
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        stringResource(Res.string.followers_lowercase),
                                                        color = MaterialTheme.onSurfaceAlpha
                                                    )
                                                }
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(
                                                        following.format(),
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        stringResource(Res.string.following_lowercase),
                                                        color = MaterialTheme.onSurfaceAlpha
                                                    )
                                                }
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(
                                                        state.profile.posts.format(),
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        stringResource(Res.string.posts_lowercase),
                                                        color = MaterialTheme.onSurfaceAlpha
                                                    )
                                                }
                                            }
                                            ParsedContent(
                                                description,
                                                onClickHandle = { handle ->
                                                    navController.navigate(Route.Profile(handle))
                                                },
                                                onClickHashtag = {
                                                    // TODO
                                                },
                                                onClickUri = {
                                                    uri.value = it
                                                }
                                            )
                                        }
                                    }
                                    HorizontalDivider(Modifier.fillMaxWidth())
                                    // TODO swipe refresh
                                }
                            }
                        }
                        pagerEmptyItem(posts, Res.string.no_posts)
                        posts?.let { posts ->
                            itemsWithDivider(posts.itemCount) { idx ->
                                val post = posts[idx] ?: return@itemsWithDivider
                                PostCard(
                                    post,
                                    state.profile.name,
                                    onClickUri = {
                                        uri.value = it
                                    }
                                )
                            }
                        }
                        pagerStateItem(posts)
                    }
                }
            }
            UriDialog(
                uri.value,
                onDismissRequest = {
                    uri.value = null
                }
            )
            ShareSheet(
                shareSheetUri.value,
                onDismissRequest = {
                    shareSheetUri.value = null
                }
            )
        }
    }
}

@Composable
private fun Avatar(
    avatar: String?
) {
    val navController = LocalNavController.current
    val instanceInfo = LocalInstanceInfo.current

    val backgroundColor = MaterialTheme.colorScheme.background
    val noContentColor = MaterialTheme.noContent

    Box(
        Modifier
            .wrapContentSize()
            .offset(x = 16.dp, y = BannerHeight.times(0.75f))
            .zIndex(2f)
    ) {
        if (instanceInfo != null && avatar != null) {
            AsyncImage(
                model = "${instanceInfo.fqdn}${avatar}",
                contentDescription = null,
                modifier = Modifier
                    .size(96.dp)
                    .drawWithCache {
                        onDrawBehind {
                            drawCircle(
                                backgroundColor,
                                (size.width / 2) + 8f
                            )
                        }
                    }
                    .clip(CircleShape)
                    .invisibleClickable {
                        navController.navigate(Route.Images(listOf(avatar), 0))
                    },
            )
        } else {
            Canvas(
                Modifier
                    .size(96.dp)
                    .drawWithCache {
                        onDrawBehind {
                            drawCircle(
                                backgroundColor,
                                (size.width / 2) + 8f
                            )
                        }
                    }
            ) {
                drawCircle(noContentColor)
            }
        }
    }
}

@Composable
private fun ShareButtonBox(
    onClick: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .zIndex(1f)
    ) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Icon(
                painterResource(Res.drawable.baseline_share_24),
                contentDescription = stringResource(Res.string.share)
            )
        }
    }
}
