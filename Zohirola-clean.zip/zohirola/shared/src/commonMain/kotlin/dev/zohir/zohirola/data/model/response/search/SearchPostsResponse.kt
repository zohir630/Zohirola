package dev.zohir.zohirola.data.model.response.search

import dev.zohir.zohirola.data.model.response.Post
import kotlinx.serialization.Serializable

@Serializable
data class SearchPostsResponse(
    val posts: List<Post>,
    val cursor: String?
)
