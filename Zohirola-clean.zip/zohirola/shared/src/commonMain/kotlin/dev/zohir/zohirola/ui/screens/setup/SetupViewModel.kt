package dev.zohir.zohirola.ui.screens.setup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.zohir.zohirola.data.CustomResource
import dev.zohir.zohirola.data.model.response.ResponseError
import dev.zohir.zohirola.data.model.response.ServiceUnavailable
import dev.zohir.zohirola.repository.EventBusRepository
import dev.zohir.zohirola.repository.ZohirolaRepository
import dev.zohir.zohirola.repository.StoreRepository
import io.github.aakira.napier.Napier
import io.ktor.client.call.NoTransformationFoundException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.koin.core.annotation.Named
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.minimum_server_version
import zohirola.shared.generated.resources.non_json_response

private typealias State = SetupContract.State

class SetupViewModel(
    private val storeRepository: StoreRepository,
    private val zohirolaRepository: ZohirolaRepository,
    private val eventBusRepository: EventBusRepository,
    @Named("io") private val ioDispatcher: CoroutineDispatcher
): ViewModel() {

    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            complete = false,
            loading = false,
            error = null
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        viewModelScope.launch(ioDispatcher) {
            checkInstance(storeRepository.getInstanceFQDN() ?: return@launch)
        }
    }

    fun checkInstance(
        url: String
    ) = viewModelScope.launch(ioDispatcher) {
        _state.update {
            it.copy(
                loading = true,
                error = null
            )
        }
        try {
            val info = zohirolaRepository.getInstanceInfo(url.dropLastWhile { it == '/' })
            _state.update {
                it.copy(loading = false)
            }
            // Zohirola only officially supports
            if ((info.versionCode ?: 0) < 100) {
                 eventBusRepository.customResource(CustomResource(Res.string.minimum_server_version, arrayOf("1.0.0+")))
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(
                    loading = false,
                    error = e.error
                )
            }
        } catch (_: NoTransformationFoundException) {
            _state.update {
                it.copy(
                    loading = false,
                    error = ServiceUnavailable(getString(Res.string.non_json_response))
                )
            }
        } catch (e: Exception) {
            Napier.e(e.toString())
            _state.update {
                it.copy(
                    loading = false,
                    error = ServiceUnavailable(e.message.toString())
                )
            }
        }
    }

    fun login(
        username: String,
        password: String
    ) = viewModelScope.launch(ioDispatcher) {
        _state.update {
            it.copy(
                loading = true,
                error = null
            )
        }
        try {
            storeRepository.setToken(zohirolaRepository.login(username, password).token)
            storeRepository.setSetup(true)
            _state.update {
                it.copy(complete = true)
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(
                    loading = false,
                    error = e.error
                )
            }
        } catch (e: Exception) {
            _state.update {
                it.copy(
                    loading = false,
                    error = ServiceUnavailable(e.message.toString())
                )
            }
        }
    }

    fun skip() {
        viewModelScope.launch(ioDispatcher) {
            storeRepository.setSetup(true)
        }
        _state.update {
            it.copy(complete = true)
        }
    }

    fun goBack() {
        viewModelScope.launch(ioDispatcher) {
            storeRepository.resetFqdn()
        }
    }

}
