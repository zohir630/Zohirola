package dev.zohir.zohirola.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil3.ImageLoader
import dev.zohir.zohirola.repository.ZohirolaRepository
import dev.zohir.zohirola.repository.StoreRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.Named

private typealias State = SettingsContract.SettingsState

class SettingsViewModel(
    private val imageLoader: ImageLoader,
    private val storeRepository: StoreRepository,
    private val zohirolaRepository: ZohirolaRepository,
    @Named("io") private val ioDispatcher: CoroutineDispatcher
): ViewModel() {

    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            memoryCacheBytes = null,
            diskCacheBytes = null
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        updateCacheSize()
    }

    fun updateCacheSize() {
        _state.update {
            it.copy(
                memoryCacheBytes = imageLoader.memoryCache?.size,
                diskCacheBytes = imageLoader.diskCache?.size
            )
        }
    }

    fun clearImageCache() {
        imageLoader.memoryCache?.clear()
        imageLoader.diskCache?.clear()
        updateCacheSize()
    }

    fun wipe() {
        clearImageCache()
        viewModelScope.launch(ioDispatcher) {
            storeRepository.clear()
        }
    }

    fun refreshInstanceFeatures(fqdn: String?) {
        fqdn ?: return
        viewModelScope.launch(ioDispatcher) {
            zohirolaRepository.getInstanceInfo(fqdn)
        }
    }

}
