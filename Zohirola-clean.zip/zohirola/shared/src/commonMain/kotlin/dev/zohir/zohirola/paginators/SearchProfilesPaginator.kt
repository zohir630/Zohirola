package dev.zohir.zohirola.paginators

import dev.zohir.zohirola.data.model.response.Actor
import dev.zohir.zohirola.paginators.base.StringPagingSource
import dev.zohir.zohirola.repository.ZohirolaRepository

class SearchProfilesPaginator(
    private val query: String,
    private val zohirolaRepository: ZohirolaRepository
): StringPagingSource<Actor>() {

    override suspend fun fetchPage(cursor: String?): Pair<List<Actor>, String?> {
        val response = zohirolaRepository.searchProfiles(query, cursor)
        return response.actors to response.cursor
    }

}
