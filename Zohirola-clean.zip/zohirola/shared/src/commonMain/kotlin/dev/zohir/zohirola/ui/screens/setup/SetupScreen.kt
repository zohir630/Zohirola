package dev.zohir.zohirola.ui.screens.setup

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.LocalLayoutType
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.LocalSnackbar
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.LoadingPage
import dev.zohir.zohirola.ui.components.buttons.BackButtonBox
import dev.zohir.zohirola.ui.components.buttons.LoadingButton
import dev.zohir.zohirola.util.ktx.dismissableSnackbar
import dev.zohir.zohirola.util.ktx.isWide
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_check_24
import zohirola.shared.generated.resources.baseline_close_24
import zohirola.shared.generated.resources.get_started
import zohirola.shared.generated.resources.get_started_description
import zohirola.shared.generated.resources.instance_url
import zohirola.shared.generated.resources.login_button
import zohirola.shared.generated.resources.login_description
import zohirola.shared.generated.resources.password
import zohirola.shared.generated.resources.server_feature_following
import zohirola.shared.generated.resources.server_feature_nsfw
import zohirola.shared.generated.resources.server_feature_registration
import zohirola.shared.generated.resources.server_feature_timeline
import zohirola.shared.generated.resources.skip
import zohirola.shared.generated.resources.zohirola_alpha
import zohirola.shared.generated.resources.username
import zohirola.shared.generated.resources.welcome

@Composable
fun SetupScreen(
    viewModel: SetupViewModel = koinViewModel()
) {
    val navController = LocalNavController.current
    val snackbar = LocalSnackbar.current
    val layout = LocalLayoutType.current
    val instanceInfo = LocalInstanceInfo.current

    val state = viewModel.state.collectAsState().value

    var instanceUrl by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(state.error) {
        state.error?.let { error ->
            if (error.errors.isNullOrEmpty()) {
                snackbar.dismissableSnackbar(error.message)
            } else {
                snackbar.dismissableSnackbar("${error.message}\n${error.errors.joinToString("\n")}")
            }
        }
    }

    LaunchedEffect(state.complete) {
        if (state.complete) {
            navController.navigate(Route.BottomNavRoute.Search)
        }
    }

    when {
        state.loading -> LoadingPage()
        else -> {
            AnimatedContent(
                instanceInfo?.fqdn
            ) { fqdn ->
                if (fqdn == null) {
                    if (layout.isWide()) {
                        Row(
                            Modifier
                                .fillMaxSize()
                                .imePadding(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Welcome(Modifier.weight(1f))
                            VerticalDivider(Modifier.fillMaxHeight(0.6f))
                            Info(
                                loading = state.loading,
                                url = instanceUrl,
                                modifier = Modifier.weight(1f),
                                onUrlChange = {
                                    instanceUrl = it
                                },
                                checkInstance = {
                                    viewModel.checkInstance(instanceUrl)
                                }
                            )
                        }
                    } else {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .imePadding(),
                            verticalArrangement = Arrangement.SpaceAround,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Welcome()
                            Info(
                                loading = state.loading,
                                url = instanceUrl,
                                onUrlChange = {
                                    instanceUrl = it
                                },
                                checkInstance = {
                                    viewModel.checkInstance(instanceUrl)
                                }
                            )
                        }
                    }
                } else {
                    BackButtonBox(
                        onClick = {
                            if (instanceInfo?.setup == true) {
                                navController.popBackStack()
                            } else {
                                viewModel.goBack()
                            }
                        }
                    )
                    if (layout.isWide()) {
                        Row(
                            Modifier
                                .fillMaxSize()
                                .imePadding(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            InstanceInfoDetails(Modifier.weight(1f))
                            VerticalDivider(Modifier.fillMaxHeight(0.6f))
                            Account(
                                loading = state.loading,
                                modifier = Modifier.weight(1f),
                                skip = viewModel::skip,
                                login = viewModel::login
                            )
                        }
                    } else {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .imePadding(),
                            verticalArrangement = Arrangement.SpaceAround,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            InstanceInfoDetails()
                            Account(
                                loading = state.loading,
                                skip = viewModel::skip,
                                login = viewModel::login
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Welcome(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(Res.string.welcome),
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold
        )

        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = CardDefaults.shape
        ) {
            Text(
                stringResource(Res.string.zohirola_alpha),
                modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp)
            )
        }
    }
}

@Composable
private fun Info(
    loading: Boolean,
    url: String,
    modifier: Modifier = Modifier,
    onUrlChange: (url: String) -> Unit,
    checkInstance: () -> Unit
) {
    val focusManager = LocalFocusManager.current

    val instanceUrlRegex = remember { Regex("^http(s)?://.*$") }

    Column(
        modifier,
        verticalArrangement = Arrangement.spacedBy(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            stringResource(Res.string.get_started_description),
            textAlign = TextAlign.Center
        )
        OutlinedTextField(
            value = url,
            onValueChange = onUrlChange,
            label = { Text(stringResource(Res.string.instance_url)) },
            placeholder = { Text("https://your-instance.example") },
            maxLines = 1
        )
        LoadingButton(
            onClick = {
                focusManager.clearFocus()
                checkInstance()
            },
            loading = loading,
            enabled = !loading && instanceUrlRegex.matches(url)
        ) {
            Text(stringResource(Res.string.get_started))
        }
    }
}

@Composable
private fun InstanceInfoDetails(
    modifier: Modifier = Modifier
) {
    val instanceInfo = LocalInstanceInfo.current

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Feature(stringResource(Res.string.server_feature_following), instanceInfo?.following)
        Feature(stringResource(Res.string.server_feature_timeline), instanceInfo?.timeline)
        Feature(stringResource(Res.string.server_feature_registration), instanceInfo?.registration)
        Feature(stringResource(Res.string.server_feature_nsfw), instanceInfo?.nsfw)
    }
}

@Composable
private fun Feature(
    feature: String,
    enabled: Boolean?
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            Modifier.weight(0.33f),
            contentAlignment = Alignment.CenterEnd
        ) {
            Icon(
                if (enabled == true) painterResource(Res.drawable.baseline_check_24) else painterResource(Res.drawable.baseline_close_24),
                contentDescription = null,
                modifier = Modifier
            )
        }
        Text(
            feature,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun Account(
    loading: Boolean,
    modifier: Modifier = Modifier,
    skip: () -> Unit,
    login: (
        username: String,
        password: String
    ) -> Unit
) {
    val focusManager = LocalFocusManager.current

    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }

    Column(
        modifier,
        verticalArrangement = Arrangement.spacedBy(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            stringResource(Res.string.login_description),
            textAlign = TextAlign.Center
        )
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            placeholder = { Text(stringResource(Res.string.username)) },
            maxLines = 1
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            placeholder = { Text(stringResource(Res.string.password)) },
            maxLines = 1
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(32.dp)
        ) {
            OutlinedButton(
                onClick = {
                    focusManager.clearFocus()
                    skip()
                }
            ) {
                Text(stringResource(Res.string.skip))
            }
            LoadingButton(
                onClick = {
                    focusManager.clearFocus()
                    login(username, password)
                },
                loading = loading,
                enabled = !loading
            ) {
                Text(stringResource(Res.string.login_button))
            }
        }
    }
}
