package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.ui.components.buttons.IconTextButton
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_refresh_24
import zohirola.shared.generated.resources.try_again

@Composable
fun RefreshPage(
    message: String,
    onClick: () -> Unit
) {
    Box(
        Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        RefreshButton(message, onClick)
    }
}

@Composable
private fun RefreshButton(
    message: String,
    onClick: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message)
        IconTextButton(
            icon = painterResource(Res.drawable.baseline_refresh_24),
            text = stringResource(Res.string.try_again),
            onClick = onClick
        )
    }
}
