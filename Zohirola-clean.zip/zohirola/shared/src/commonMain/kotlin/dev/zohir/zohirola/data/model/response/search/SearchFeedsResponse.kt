package dev.zohir.zohirola.data.model.response.search

import dev.zohir.zohirola.data.model.response.Feed
import kotlinx.serialization.Serializable

@Serializable
data class SearchFeedsResponse(
    val feeds: List<Feed>,
    val cursor: String? = null
)
