package dev.zohir.zohirola.ui.components.buttons

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_keyboard_arrow_up_24
import zohirola.shared.generated.resources.scroll_to_top

@Composable
fun ScrollToTopButton(
    visible: Boolean,
    onClick: () -> Unit
) {
    AnimatedVisibility(
        visible,
        enter = scaleIn(tween(300)),
        exit = scaleOut(tween(300))
    ) {
        FloatingActionButton(
            onClick = onClick
        ) {
            Icon(painterResource(Res.drawable.baseline_keyboard_arrow_up_24), stringResource(Res.string.scroll_to_top))
        }
    }
}
