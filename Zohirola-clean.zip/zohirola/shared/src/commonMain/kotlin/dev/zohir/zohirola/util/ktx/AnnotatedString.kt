package dev.zohir.zohirola.util.ktx

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.style.TextDecoration

fun AnnotatedString.Builder.highlightedText(
    text: String,
    color: Color
) {
    pushStyle(
        SpanStyle(
            color = color,
            textDecoration = TextDecoration.None
        )
    )
    append(text)
    pop()
}
