package dev.zohir.zohirola.ui.screens.profile

import androidx.paging.PagingData
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Profile
import dev.zohir.zohirola.data.model.response.ZohirolaError
import kotlinx.coroutines.flow.Flow

class ProfileContract {

    data class ProfileState(
        val profile: Profile?,
        val pager: Flow<PagingData<Post>>?,
        val error: ZohirolaError?,
        val followUpdateLoading: Boolean,
        val refresh: Boolean
    )

}
