package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.ui.components.post.UriDialog
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha

val EmbedThumbnailHeight = 196.dp

@Composable
fun ExternalEmbed(
    post: Post
) {
    post.externalUri ?: return

    val instanceInfo = LocalInstanceInfo.current

    instanceInfo ?: return

    var uri by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        Spacer(Modifier.height(4.dp))
        Card(
            Modifier
                .fillMaxWidth()
                .clickable {
                    uri = post.externalUri
                }
        ) {
            Column(
                Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {

                post.externalThumb?.let { thumbnail ->
                    AsyncImage(
                        model = "${instanceInfo.fqdn}${thumbnail}",
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(EmbedThumbnailHeight)
                    )
                }
                post.externalTitle?.let { title ->
                    Text(
                        title,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.horizontalPadding()
                    )
                }
                post.externalDescription?.let { description ->
                    Text(
                        description,
                        modifier = Modifier.horizontalPadding()
                    )
                    HorizontalDivider(Modifier.horizontalPadding())
                }
                Text(
                    post.externalUri,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.onSurfaceAlpha,
                    modifier = Modifier.horizontalPadding()
                )
                Spacer(Modifier.height(4.dp))
            }
        }
    }
    UriDialog(
        uri,
        onDismissRequest = {
            uri = null
        }
    )
}

private fun Modifier.horizontalPadding() = then(padding(horizontal = 8.dp))
