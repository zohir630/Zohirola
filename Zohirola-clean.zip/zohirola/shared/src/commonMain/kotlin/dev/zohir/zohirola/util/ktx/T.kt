package dev.zohir.zohirola.util.ktx

inline fun <T> T.applyIf(
    condition: Boolean,
    block: T.() -> Unit
): T {
    if (condition) {
        block()
    }
    return this
}
