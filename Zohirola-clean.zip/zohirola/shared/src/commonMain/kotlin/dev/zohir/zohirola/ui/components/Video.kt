package dev.zohir.zohirola.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import dev.zohir.zohirola.LocalInstanceInfo
import io.github.kdroidfilter.composemediaplayer.AudioMode
import io.github.kdroidfilter.composemediaplayer.CacheConfig
import io.github.kdroidfilter.composemediaplayer.InitialPlayerState
import io.github.kdroidfilter.composemediaplayer.InterruptionMode
import io.github.kdroidfilter.composemediaplayer.VideoPlayerState
import io.github.kdroidfilter.composemediaplayer.VideoPlayerSurface
import io.github.kdroidfilter.composemediaplayer.rememberVideoPlayerState
import kotlinx.coroutines.delay
import org.jetbrains.compose.resources.painterResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_fullscreen_24
import zohirola.shared.generated.resources.baseline_fullscreen_exit_24
import zohirola.shared.generated.resources.baseline_pause_24
import zohirola.shared.generated.resources.baseline_play_arrow_24
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun Video(
    uri: String?
) {
    uri ?: return

    val instanceInfo = LocalInstanceInfo.current

    instanceInfo ?: return

    val state = rememberVideoPlayerState(
        audioMode = AudioMode(InterruptionMode.DuckOthers),
        cacheConfig = CacheConfig(
            enabled = true
        )
    )
    var controlsShowing by remember { mutableStateOf(true) }

    state.onPlaybackEnded = {
        controlsShowing = true
    }

    LaunchedEffect(Unit) {
        state.loop = false
    }

    LaunchedEffect(uri) {
        state.openUri("${instanceInfo.fqdn}${uri}", InitialPlayerState.PAUSE)
    }

    LaunchedEffect(controlsShowing, state.isPlaying) {
        if (controlsShowing && state.isPlaying) {
            delay(2000L.milliseconds)
            controlsShowing = false
        }
    }

    Box(
        Modifier.fillMaxWidth()
    ) {
        VideoPlayerSurface(
            playerState = state,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(state.aspectRatio)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    controlsShowing = !controlsShowing
                },
            contentScale = ContentScale.Fit,
            overlay = {
                if (state.isFullscreen) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                controlsShowing = !controlsShowing
                            }
                    ) {
                        Overlay(
                            state = state,
                            visible = controlsShowing
                        )
                    }
                } else {
                    Overlay(
                        state = state,
                        visible = controlsShowing
                    )
                }
            }
        )

        if (state.isLoading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }
}

@Composable
fun Overlay(
    state: VideoPlayerState,
    visible: Boolean
) {
    AnimatedVisibility(
        visible,
        modifier = Modifier
            .fillMaxSize(),
        enter = fadeIn(spring(stiffness = Spring.StiffnessHigh / 2)),
        exit = fadeOut(spring(stiffness = Spring.StiffnessMedium))
    ) {
        Box(
            Modifier.fillMaxSize()
        ) {
            FilledIconButton(
                onClick = {
                    if (state.isPlaying) {
                        state.pause()
                    } else {
                        state.play()
                    }
                },
                modifier = Modifier
                    .size(72.dp)
                    .align(Alignment.Center),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.White.copy(alpha = 0.15f),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    if (state.isPlaying) painterResource(Res.drawable.baseline_pause_24) else painterResource(Res.drawable.baseline_play_arrow_24),
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                )
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        text = "${state.positionText}  /  ${state.durationText}",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodySmall,
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Slider(
                            value = state.sliderPos,
                            onValueChange = { state.seekStart(it) },
                            onValueChangeFinished = { state.seekFinished() },
                            valueRange = 0f..1000f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f),
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                state.toggleFullscreen()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                if (state.isFullscreen) painterResource(Res.drawable.baseline_fullscreen_exit_24) else painterResource(Res.drawable.baseline_fullscreen_24) ,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
