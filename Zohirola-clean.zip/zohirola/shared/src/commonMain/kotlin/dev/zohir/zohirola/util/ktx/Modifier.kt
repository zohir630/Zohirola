package dev.zohir.zohirola.util.ktx

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.unit.dp

fun Modifier.horizontalContentPadding() = padding(horizontal = 12.dp)

fun Modifier.invisibleClickable(
    onClick: () -> Unit
) = composed {
    clickable(
        interactionSource = remember {MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

fun Modifier.conditional(
    condition: Boolean,
    modifier: Modifier.() -> Modifier
): Modifier = if (condition) {
    then(modifier(Modifier))
} else {
    this
}
