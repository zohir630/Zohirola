package dev.zohir.zohirola.ui.screens.image

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.SubcomposeAsyncImage
import coil3.compose.SubcomposeAsyncImageContent
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.LocalNavController
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_chevron_backward_24
import zohirola.shared.generated.resources.baseline_chevron_forward_24
import zohirola.shared.generated.resources.baseline_close_24
import zohirola.shared.generated.resources.close
import kotlin.math.abs
import kotlin.math.exp

private const val MinScale = 1f
private const val MaxScale = 4f
private const val DoubleTapScale = 2.5f
private const val WheelZoomSpeed = 0.15f
private const val PanSpeed = 1.25f

@Composable
fun ImageScreen(
    viewModel: ImageViewModel = koinViewModel()
) {
    val navController = LocalNavController.current
    val instanceInfo = LocalInstanceInfo.current

    instanceInfo ?: return

    val state = viewModel.state.collectAsStateWithLifecycle().value
    val zoom = remember { ZoomState() }
    val onSwipe: (Int) -> Unit = {
        if (it > 0) {
            viewModel.next()
        } else {
            viewModel.previous()
        }
    }

    Dialog(
        properties = DialogProperties(usePlatformDefaultWidth = false),
        onDismissRequest = {
            navController.popBackStack()
        }
    ) {
        Surface(
            Modifier
                .fillMaxSize()
                .onKeyEvent { keyEvent ->
                    when (keyEvent.key) {
                        Key.DirectionRight -> {
                            viewModel.next()
                            return@onKeyEvent true
                        }
                        Key.DirectionLeft -> {
                            viewModel.previous()
                            return@onKeyEvent true
                        }
                        else -> {
                            return@onKeyEvent false
                        }
                    }
                },
            color = Color.Transparent
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged {
                        zoom.viewport = it
                    }
                    .pointerInput(Unit) {
                        detectTapGestures {
                            navController.popBackStack()
                        }
                    }
                    .swipe(zoom, onSwipe)
            ) {
                ExitButton {
                    navController.popBackStack()
                }
                when (state.images) {
                    null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    else -> {
                        val image = if (state.idx in state.failedFullsize) {
                            state.images[state.idx]
                        } else {
                            state.fullsize?.get(state.idx) ?: state.images[state.idx]
                        }
                        LaunchedEffect(image) {
                            zoom.reset()
                        }
                        SubcomposeAsyncImage(
                            model = "${instanceInfo.fqdn}${image}",
                            contentDescription = null,
                            onError = {
                                viewModel.fullsizeFailed(state.idx)
                            },
                            loading = {
                                Box(Modifier.fillMaxSize()) {
                                    CircularProgressIndicator(
                                        Modifier
                                            .align(Alignment.Center)
                                            .size(32.dp)
                                    )
                                }
                            },
                            success = {
                                val intrinsic = painter.intrinsicSize
                                val modifier = if (intrinsic.width > 0f && intrinsic.height > 0f &&
                                    intrinsic.width.isFinite() && intrinsic.height.isFinite()
                                ) {
                                    Modifier
                                        .wrapContentSize(Alignment.Center)
                                        .aspectRatio(intrinsic.width / intrinsic.height)
                                        .zoomable(zoom)
                                        .swipe(zoom, onSwipe)
                                } else {
                                    Modifier
                                        .fillMaxSize()
                                        .zoomable(zoom)
                                        .swipe(zoom, onSwipe)
                                }
                                SubcomposeAsyncImageContent(modifier)
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        )
                        if (state.idx < state.images.size - 1) {
                            NavigateButton(
                                painterResource(Res.drawable.baseline_chevron_forward_24),
                                Alignment.CenterEnd,
                                onClick = viewModel::next
                            )
                        }
                        if (state.idx > 0) {
                            NavigateButton(
                                painterResource(Res.drawable.baseline_chevron_backward_24),
                                Alignment.CenterStart,
                                onClick = viewModel::previous
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BoxScope.ExitButton(
    onClick: () -> Unit,
) {
    IconButton(
        onClick,
        modifier = Modifier
            .align(Alignment.TopEnd)
            .zIndex(1f)
    ) {
        Icon(
            painterResource(Res.drawable.baseline_close_24),
            contentDescription = stringResource(Res.string.close)
        )
    }
}

@Composable
private fun BoxScope.NavigateButton(
    icon: Painter,
    alignment: Alignment,
    onClick: () -> Unit
) {
    IconButton(
        onClick,
        modifier = Modifier
            .align(alignment)
            .zIndex(1f)
    ) {
        Icon(
            icon,
            contentDescription = null
        )
    }
}

private class ZoomState {
    var scale by mutableFloatStateOf(MinScale)
    var offset by mutableStateOf(Offset.Zero)
    var content by mutableStateOf(IntSize.Zero)
    var viewport by mutableStateOf(IntSize.Zero)

    fun reset() {
        scale = MinScale
        offset = Offset.Zero
    }

    fun zoomedOffset(centroid: Offset, current: Float, next: Float): Offset {
        val center = Offset(content.width / 2f, content.height / 2f)
        return offset + (centroid - center) * (current - next)
    }

    fun clamped(candidate: Offset, scale: Float): Offset {
        val maxX = (content.width * scale - viewport.width) / 2f
        val maxY = (content.height * scale - viewport.height) / 2f
        return Offset(
            if (maxX > 0f) candidate.x.coerceIn(-maxX, maxX) else 0f,
            if (maxY > 0f) candidate.y.coerceIn(-maxY, maxY) else 0f
        )
    }
}

private fun Modifier.zoomable(state: ZoomState): Modifier = onSizeChanged { state.content = it }
    .graphicsLayer {
        scaleX = state.scale
        scaleY = state.scale
        translationX = state.offset.x
        translationY = state.offset.y
    }
    .pointerInput(state) {
        detectTransformGestures { centroid, pan, zoomFactor, _ ->
            val current = state.scale
            val next = (current * zoomFactor).coerceIn(MinScale, MaxScale)
            if (next == MinScale) {
                state.reset()
                return@detectTransformGestures
            }
            var nextOffset = state.offset
            if (zoomFactor != 1f) nextOffset = state.zoomedOffset(centroid, current, next)
            if (current > MinScale) nextOffset += pan * (current * PanSpeed)
            state.offset = state.clamped(nextOffset, next)
            state.scale = next
        }
    }
    .pointerInput(state) {
        detectTapGestures(
            onTap = {},
            onDoubleTap = { centroid ->
                if (state.scale > MinScale) {
                    state.reset()
                } else {
                    state.offset = state.clamped(
                        state.zoomedOffset(centroid, state.scale, DoubleTapScale),
                        DoubleTapScale
                    )
                    state.scale = DoubleTapScale
                }
            }
        )
    }
    .pointerInput(state) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent()
                if (event.type != PointerEventType.Scroll) continue
                val change = event.changes.firstOrNull() ?: continue
                val next = (state.scale * exp(-change.scrollDelta.y * WheelZoomSpeed)).coerceIn(MinScale, MaxScale)
                if (next == state.scale) continue
                state.offset = state.clamped(
                    state.zoomedOffset(change.position, state.scale, next),
                    next
                )
                state.scale = next
            }
        }
    }

private fun Modifier.swipe(state: ZoomState, onSwipe: (Int) -> Unit): Modifier = pointerInput(state) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        var totalX = 0f
        var totalY = 0f
        while (true) {
            val event = awaitPointerEvent()
            val changes = event.changes
            if (changes.isEmpty() || changes.size > 1) break
            val change = changes[0]
            if (!change.pressed) {
                val threshold = (state.viewport.width / 4f).coerceAtLeast(96f)
                if (state.scale == MinScale && abs(totalX) > threshold && abs(totalX) > abs(totalY) * 2f) {
                    onSwipe(if (totalX < 0f) 1 else -1)
                }
                break
            }
            if (change.isConsumed) break
            val delta = change.position - change.previousPosition
            totalX += delta.x
            totalY += delta.y
            if (state.scale == MinScale && abs(totalX) > viewConfiguration.touchSlop && abs(totalX) > abs(totalY) * 2f) {
                change.consume()
            }
        }
    }
}
