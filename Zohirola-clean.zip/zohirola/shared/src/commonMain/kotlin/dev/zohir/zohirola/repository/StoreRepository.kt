package dev.zohir.zohirola.repository

import com.russhwolf.settings.ExperimentalSettingsApi
import com.russhwolf.settings.coroutines.FlowSettings
import dev.zohir.zohirola.InstanceInfoState
import dev.zohir.zohirola.util.combine
import kotlinx.coroutines.flow.Flow

interface StoreRepository {
    // Auth
    suspend fun setToken(token: String)
    suspend fun getToken(): String?
    suspend fun getTokenFlow(): Flow<String?>
    suspend fun deleteToken()

    // Server
    suspend fun setInstanceFQDN(fqdn: String)
    suspend fun getInstanceFQDN(): String?
    suspend fun setInstanceVersion(version: Int)
    suspend fun setTimelines(enabled: Boolean)
    suspend fun setFollowing(enabled: Boolean)
    suspend fun setRegistration(enabled: Boolean)
    suspend fun setNsfw(enabled: Boolean)

    // Zohirola
    suspend fun setSetup(complete: Boolean)

    // Flow
    fun getInstanceInfoFlow(): Flow<InstanceInfoState>

    // Actions
    suspend fun resetFqdn()
    suspend fun clear()
}

@OptIn(ExperimentalSettingsApi::class)
class StoreRepositoryImpl(
    private val settings: FlowSettings
): StoreRepository {

    override suspend fun setToken(token: String) = settings.putString(SettingsKeys.Token.key, token)
    override suspend fun getToken(): String? = settings.getStringOrNull(SettingsKeys.Token.key)
    override suspend fun getTokenFlow(): Flow<String?> = settings.getStringOrNullFlow(SettingsKeys.Token.key)
    override suspend fun deleteToken() = settings.remove(SettingsKeys.Token.key)

    override suspend fun setInstanceFQDN(fqdn: String) = settings.putString(SettingsKeys.InstanceFQDN.key, fqdn)
    override suspend fun getInstanceFQDN(): String? = settings.getStringOrNull(SettingsKeys.InstanceFQDN.key)
    override suspend fun setInstanceVersion(version: Int) = settings.putInt(SettingsKeys.InstanceVersion.key, version)
    override suspend fun setTimelines(enabled: Boolean) = settings.putBoolean(SettingsKeys.Timelines.key, enabled)
    override suspend fun setFollowing(enabled: Boolean) = settings.putBoolean(SettingsKeys.Following.key, enabled)
    override suspend fun setRegistration(enabled: Boolean) = settings.putBoolean(SettingsKeys.Registration.key, enabled)
    override suspend fun setNsfw(enabled: Boolean) = settings.putBoolean(SettingsKeys.NSFW.key, enabled)

    override suspend fun setSetup(complete: Boolean) = settings.putBoolean(SettingsKeys.Setup.key, complete)

    override fun getInstanceInfoFlow(): Flow<InstanceInfoState> = combine(
        settings.getStringOrNullFlow(SettingsKeys.Token.key),
        settings.getStringOrNullFlow(SettingsKeys.InstanceFQDN.key),
        settings.getIntOrNullFlow(SettingsKeys.InstanceVersion.key),
        settings.getBooleanOrNullFlow(SettingsKeys.Timelines.key),
        settings.getBooleanOrNullFlow(SettingsKeys.Following.key),
        settings.getBooleanOrNullFlow(SettingsKeys.Registration.key),
        settings.getBooleanOrNullFlow(SettingsKeys.NSFW.key),
        settings.getBooleanOrNullFlow(SettingsKeys.Setup.key)
    ) { token, fqdn, version, timeline, following, registration, nsfw, setup ->
        InstanceInfoState(
            token = token,
            fqdn = fqdn,
            version = version ?: 0,
            following = following == true,
            timeline = timeline == true,
            registration = registration == true,
            nsfw = nsfw == true,
            setup = setup == true
        )
    }

    override suspend fun resetFqdn() {
        settings.remove(SettingsKeys.InstanceFQDN.key)
    }

    override suspend fun clear() {
        settings.clear()
    }

}

private enum class SettingsKeys(
    val key: String
) {
    // Auth
    Token("token"),

    // Instance
    InstanceFQDN("fqdn"),
    InstanceVersion("version"),
    Timelines("timelines"),
    Following("following"),
    Registration("registration"),
    NSFW("nsfw"),

    // Zohirola
    Setup("setup")
}
