package dev.zohir.zohirola.plugins

import dev.zohir.zohirola.data.model.response.ResponseError
import dev.zohir.zohirola.data.model.response.ZohirolaError
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.HttpCallValidatorConfig
import io.ktor.client.plugins.RedirectResponseException
import io.ktor.client.plugins.ServerResponseException
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
private data class UpstreamError(
    val message: String,
    val errors: List<String>? = null
)

private data class UnwrappedError(
    val status: HttpStatusCode,
    val body: String
)

fun HttpCallValidatorConfig.handleResponse(
    json: Json
) {
    handleResponseExceptionWithRequest { ex, _ ->
        val unwrapped = ex.unwrap() ?: return@handleResponseExceptionWithRequest
        if (unwrapped.status != HttpStatusCode.OK) {
            val error = json.decodeFromString<UpstreamError>(unwrapped.body)
            throw ResponseError(
                ZohirolaError(
                    code = unwrapped.status.value,
                    message = error.message,
                    errors = error.errors
                )
            )
        }
    }
}

private suspend fun Throwable.unwrap(): UnwrappedError? = when (this) {
    is RedirectResponseException,
    is ClientRequestException,
    is ServerResponseException -> UnwrappedError(this.response.status, this.response.bodyAsText())
    else -> null
}
