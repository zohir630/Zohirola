package dev.zohir.zohirola.ui.screens.feed

import androidx.paging.PagingData
import dev.zohir.zohirola.data.model.response.Post
import kotlinx.coroutines.flow.Flow

class FeedContract {

    data class FeedState(
        val pager: Flow<PagingData<Post>>?,
        val refresh: Boolean
    )

}
