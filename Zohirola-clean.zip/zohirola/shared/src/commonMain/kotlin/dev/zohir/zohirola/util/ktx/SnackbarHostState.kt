package dev.zohir.zohirola.util.ktx

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import org.jetbrains.compose.resources.getString
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.authentication_expired
import zohirola.shared.generated.resources.login
import zohirola.shared.generated.resources.login_required

suspend fun SnackbarHostState.loginPrompt(
    expired: Boolean = false,
    callback: () -> Unit
) {
    when (
        showSnackbar(
            message = if (expired) getString(Res.string.authentication_expired) else getString(Res.string.login_required),
            actionLabel = getString(Res.string.login),
            withDismissAction = true,
            duration = SnackbarDuration.Indefinite
        )
    ) {
        SnackbarResult.ActionPerformed -> callback()
        SnackbarResult.Dismissed -> currentSnackbarData?.dismiss()
    }
}

suspend fun SnackbarHostState.dismissableSnackbar(
    message: String,
    duration: SnackbarDuration = SnackbarDuration.Long
) = showSnackbar(
    message,
    withDismissAction = true,
    duration = duration
)
