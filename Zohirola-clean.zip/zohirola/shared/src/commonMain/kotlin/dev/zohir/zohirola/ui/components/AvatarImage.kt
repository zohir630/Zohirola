package dev.zohir.zohirola.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import dev.zohir.zohirola.LocalInstanceInfo
import dev.zohir.zohirola.util.ktx.conditional

val DefaultAvatarImageSize = 48.dp

@Composable
fun AvatarImage(
    avatar: String?,
    size: Dp = DefaultAvatarImageSize,
    padding: PaddingValues = PaddingValues(),
    backgroundRadius: Float? = null,
    onClick: (() -> Unit)? = null
) {
    val instanceInfo = LocalInstanceInfo.current

    instanceInfo ?: return

    val backgroundColor = MaterialTheme.colorScheme.background

    AsyncImage(
        model = "${instanceInfo.fqdn}${avatar}",
        contentDescription = null,
        modifier = Modifier
            .padding(padding)
            .size(size)
            .conditional(backgroundRadius != null) {
                drawWithCache {
                    onDrawBehind {
                        drawCircle(
                            backgroundColor,
                            backgroundRadius ?: 0f
                        )
                    }
                }
            }
            .clip(CircleShape)
            .conditional(onClick != null) {
                clickable {
                    onClick?.invoke()
                }
            }
    )
}
