package dev.zohir.zohirola.ui.components

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.ui.Route
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.baseline_arrow_back_24
import zohirola.shared.generated.resources.baseline_settings_24
import zohirola.shared.generated.resources.go_back
import zohirola.shared.generated.resources.settings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(
    title: @Composable (() -> Unit)? = null
) {
    val navController = LocalNavController.current

    TopAppBar(
        title = title ?: {
            Text(
                buildAnnotatedString {
                    append("Sky")
                    withStyle(SpanStyle(MaterialTheme.colorScheme.primary)) {
                        append("lib")
                    }
                }
            )
        },
        actions = {
            IconButton(
                onClick = {
                    navController.navigate(Route.Settings)
                }
            ) {
                Icon(
                    painterResource(Res.drawable.baseline_settings_24),
                    contentDescription = stringResource(Res.string.settings)
                )
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackTopBar(
    title: @Composable (() -> Unit) = {}
) {
    val navController = LocalNavController.current

    TopAppBar(
        navigationIcon = {
            IconButton(
                onClick = {
                    navController.popBackStack()
                }
            ) {
                Icon(
                    painterResource(Res.drawable.baseline_arrow_back_24),
                    contentDescription = stringResource(Res.string.go_back)
                )
            }
        },
        title = title
    )
}
