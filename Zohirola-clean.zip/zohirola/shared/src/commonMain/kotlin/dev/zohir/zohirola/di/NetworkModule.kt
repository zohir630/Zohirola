package dev.zohir.zohirola.di

import de.jensklingenberg.ktorfit.Ktorfit
import dev.zohir.zohirola.BuildKonfig
import dev.zohir.zohirola.api.ZohirolaApi
import dev.zohir.zohirola.api.createZohirolaApi
import dev.zohir.zohirola.plugins.InstancePlugin
import dev.zohir.zohirola.plugins.ZohirolaAuthPlugin
import dev.zohir.zohirola.plugins.handleResponse
import dev.zohir.zohirola.repository.AuthRepository
import dev.zohir.zohirola.repository.StoreRepository
import io.github.aakira.napier.Napier
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpResponseValidator
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.request.header
import io.ktor.http.userAgent
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json
import org.koin.dsl.module

object NetworkModule {
    val networkModule = module {
        single {
            HttpClient {
                val json: Json = get()
                expectSuccess = true
                install(ContentNegotiation) {
                    json(json)
                }
                install(InstancePlugin) {
                    storeRepository = inject<StoreRepository>()
                }
                install(ZohirolaAuthPlugin) {
                    authRepository = inject<AuthRepository>()
                }
                install(Logging) {
                    logger = object: Logger {
                        override fun log(message: String) {
                            Napier.d(message)
                        }
                    }
                    level = LogLevel.INFO
                }
                install(HttpTimeout) {
                    requestTimeoutMillis = 15_000
                }
                defaultRequest {
                    url("https://dev.zohir.zohirola.stub/api/")
                    header("Content-Type", "application/json")
                    userAgent("Zohirola ${BuildKonfig.versionName}")
                }
                HttpResponseValidator {
                    handleResponse(json)
                }
            }
        }
        single {
            Ktorfit.Builder()
                .httpClient(get<HttpClient>())
                .build()
        }
        single<ZohirolaApi> {
            get<Ktorfit>().createZohirolaApi()
        }
    }
}
