package dev.zohir.zohirola.ui.screens.following

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import dev.zohir.zohirola.LocalNavController
import dev.zohir.zohirola.data.model.response.FollowingProfile
import dev.zohir.zohirola.ui.Route
import dev.zohir.zohirola.ui.components.AdaptiveLazyColumn
import dev.zohir.zohirola.ui.components.AvatarImage
import dev.zohir.zohirola.ui.components.TopBar
import dev.zohir.zohirola.ui.components.buttons.ScrollToTopButton
import dev.zohir.zohirola.ui.components.lazy.itemsWithDivider
import dev.zohir.zohirola.ui.components.lazy.pagerEmptyItem
import dev.zohir.zohirola.ui.components.lazy.pagerStateItem
import dev.zohir.zohirola.util.ktx.animateScrollToTop
import dev.zohir.zohirola.util.ktx.onSurfaceAlpha
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.following
import zohirola.shared.generated.resources.not_following_anyone

@Composable
fun FollowingScreen(
    viewModel: FollowingViewModel = koinViewModel()
) {
    val navController = LocalNavController.current

    val profiles = viewModel.profiles.collectAsLazyPagingItems()

    val scope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    val showScrollFab by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex > 0
        }
    }

    PullToRefreshBox(
        profiles.loadState.refresh == LoadState.Loading,
        onRefresh = profiles::refresh
    ) {
        Scaffold(
            topBar = {
                TopBar(
                    title = {
                        Text(stringResource(Res.string.following))
                    }
                )
            },
            floatingActionButton = {
                ScrollToTopButton(showScrollFab) { scope.launch { lazyListState.animateScrollToTop() } }
            }
        ) { padding ->
            AdaptiveLazyColumn(
                insets = padding,
                state = lazyListState
            ) {
                pagerEmptyItem(profiles, Res.string.not_following_anyone) // Todo display a button to search for people
                itemsWithDivider(profiles.itemCount) { idx ->
                    val profile = profiles[idx] ?: return@itemsWithDivider
                    SmallFollowingProfileCard(profile) {
                        navController.navigate(Route.Profile(profile.id))
                    }
                }
                pagerStateItem(profiles)
            }
        }
    }
}

@Composable
private fun SmallFollowingProfileCard(
    profile: FollowingProfile,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            }
            .padding(vertical = (2.5).dp)
            .padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AvatarImage(profile.avatar)
        Column {
            Text(
                profile.name,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "@${profile.id}",
                color = MaterialTheme.onSurfaceAlpha,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}
