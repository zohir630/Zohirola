package dev.zohir.zohirola.di

import dev.zohir.zohirola.paginators.FeedPaginator
import dev.zohir.zohirola.paginators.FollowingPaginator
import dev.zohir.zohirola.paginators.HomePaginator
import dev.zohir.zohirola.paginators.PostsPaginator
import dev.zohir.zohirola.paginators.SavedPostsPaginator
import org.koin.dsl.module
import org.koin.plugin.module.dsl.factory

object PaginatorModule {
    val paginatorModule = module {
        factory<HomePaginator>()
        factory<PostsPaginator>()
        factory<FeedPaginator>()
        factory<FollowingPaginator>()
        factory<SavedPostsPaginator>()
    }
}
