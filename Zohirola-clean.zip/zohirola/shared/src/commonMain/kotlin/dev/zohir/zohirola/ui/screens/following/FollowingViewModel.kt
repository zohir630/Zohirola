package dev.zohir.zohirola.ui.screens.following

import androidx.lifecycle.ViewModel
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import dev.zohir.zohirola.data.model.response.FollowingProfile
import dev.zohir.zohirola.paginators.FollowingPaginator
import kotlinx.coroutines.flow.Flow

class FollowingViewModel(
    private val followingPaginator: FollowingPaginator
): ViewModel() {

    val profiles: Flow<PagingData<FollowingProfile>> = Pager(
        config = PagingConfig(pageSize = 1), // page size not used
        pagingSourceFactory = { followingPaginator }
    ).flow

}
