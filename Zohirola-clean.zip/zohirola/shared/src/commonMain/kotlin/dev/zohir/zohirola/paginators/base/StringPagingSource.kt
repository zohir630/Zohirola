package dev.zohir.zohirola.paginators.base

import androidx.paging.PagingSource
import androidx.paging.PagingState

abstract class StringPagingSource<T: Any>: PagingSource<String, T>() {

    protected abstract suspend fun fetchPage(cursor: String?): Pair<List<T>, String?>

    final override suspend fun load(params: LoadParams<String>): LoadResult<String, T> {
        return try {
            val (items, cursor) = fetchPage(params.key)

            LoadResult.Page(
                data = items,
                prevKey = null,
                nextKey = cursor.takeIf { it != params.key }
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    final override fun getRefreshKey(state: PagingState<String, T>): String? = null

}
