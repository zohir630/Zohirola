package dev.zohir.zohirola.ui.screens.post

import androidx.compose.material3.SnackbarDuration
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.zohir.zohirola.data.CustomResource
import dev.zohir.zohirola.data.model.response.ResponseError
import dev.zohir.zohirola.data.model.response.ServiceUnavailable
import dev.zohir.zohirola.repository.EventBusRepository
import dev.zohir.zohirola.repository.ZohirolaRepository
import io.github.aakira.napier.Napier
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.annotation.Named
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.failed_to_save_post
import zohirola.shared.generated.resources.failed_to_unsave_post
import zohirola.shared.generated.resources.post_saved
import zohirola.shared.generated.resources.post_unsaved

private typealias State = PostContract.PostContractState

@OptIn(ExperimentalCoroutinesApi::class)
class PostViewModel(
    private val handle: SavedStateHandle,
    private val zohirolaRepository: ZohirolaRepository,
    private val eventBusRepository: EventBusRepository,
    @Named("default") private val defaultDispatcher: CoroutineDispatcher,
    @Named("io") private val ioDispatcher: CoroutineDispatcher
): ViewModel() {

    private var _did: String? = null
    private var _id: String? = null
    private val _state: MutableStateFlow<State> = MutableStateFlow(
        State(
            post = null,
            isSaved = null,
            replies = null,
            error = null
        )
    )
    val state: StateFlow<State>
        get() = _state.asStateFlow()

    init {
        viewModelScope.launch(defaultDispatcher) {
            combine(
                handle.getStateFlow<String?>("did", null),
                handle.getStateFlow<String?>("id", null)
            ) { did, id ->
                if (did != _did || id != _id) {
                    _did = did
                    _id = id
                    getPost(did, id)
                }
            }.stateIn(this)
        }
    }

    suspend fun getPost(
        did: String? = _did,
        id: String? = _id
    ) = withContext(ioDispatcher) {
        did ?: return@withContext
        id ?: return@withContext
        _state.update {
            it.copy(
                post = null,
                replies = null,
                error = null
            )
        }
        try {
            val response = zohirolaRepository.getProfilePost(did, id)
            _state.update {
                it.copy(
                    post = response.postReplies.post,
                    isSaved = response.isSaved == true,
                    replies = response.postReplies.replies
                )
            }
        } catch (e: ResponseError) {
            _state.update {
                it.copy(error = e.error)
            }
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            _state.update {
                it.copy(error = ServiceUnavailable(e.message.toString()))
            }
        }
    }

    suspend fun save(
        did: String,
        id: String,
        child: Boolean
    ) = withContext(ioDispatcher) {
        if (!child) {
            _state.update {
                it.copy(
                    isSaved = null
                )
            }
        }
        try {
            zohirolaRepository.savePost(did, id)
            if (!child) {
                _state.update {
                    it.copy(isSaved = true)
                }
            }
            eventBusRepository.customResource(
                CustomResource(
                    Res.string.post_saved,
                    duration = SnackbarDuration.Short
                )
            )
        } catch (e: ResponseError) {
            if (!child) {
                _state.update {
                    it.copy(isSaved = false)
                }
            }
            eventBusRepository.customResource(CustomResource(Res.string.failed_to_save_post, arrayOf(e.message ?: "unknown error")))
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            if (!child) {
                _state.update {
                    it.copy(isSaved = false)
                }
            }
            eventBusRepository.customResource(CustomResource(Res.string.failed_to_save_post, arrayOf("unknown error")))
        }
    }

    suspend fun unsave(
        did: String,
        cid: String,
        child: Boolean
    ) = withContext(ioDispatcher) {
        if (!child) {
            _state.update {
                it.copy(
                    isSaved = null
                )
            }
        }
        try {
            zohirolaRepository.unsavePost(did, cid)
            if (!child) {
                _state.update {
                    it.copy(isSaved = false)
                }
            }
            eventBusRepository.customResource(
                CustomResource(
                    Res.string.post_unsaved,
                    duration = SnackbarDuration.Short
                )
            )
        } catch (e: ResponseError) {
            if (!child) {
                _state.update {
                    it.copy(isSaved = true)
                }
            }
            eventBusRepository.customResource(CustomResource(Res.string.failed_to_unsave_post, arrayOf(e.message ?: "unknown error")))
        } catch (e: Exception) {
            Napier.e(e.message.toString())
            if (!child) {
                _state.update {
                    it.copy(isSaved = true)
                }
            }
            eventBusRepository.customResource(CustomResource(Res.string.failed_to_unsave_post, arrayOf("unknown error")))
        }
    }

}
