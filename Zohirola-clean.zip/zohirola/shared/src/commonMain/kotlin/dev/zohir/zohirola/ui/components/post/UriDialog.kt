package dev.zohir.zohirola.ui.components.post

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.jetbrains.compose.resources.stringResource
import zohirola.shared.generated.resources.Res
import zohirola.shared.generated.resources.cancel
import zohirola.shared.generated.resources.open
import zohirola.shared.generated.resources.uri_warning
import zohirola.shared.generated.resources.warning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UriDialog(
    uri: String?,
    onDismissRequest: () -> Unit
) {
    val uriHandler = LocalUriHandler.current

    if (uri != null) {
        Dialog(
            onDismissRequest = onDismissRequest
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        stringResource(Res.string.warning),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(stringResource(Res.string.uri_warning, uri)) // TODO l18n
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                    ) {
                        OutlinedButton(onClick = onDismissRequest) {
                            Text(stringResource(Res.string.cancel))
                        }
                        Button(
                            onClick = {
                                onDismissRequest()
                                try {
                                    uriHandler.openUri(uri)
                                } catch (_: IllegalArgumentException) {}
                            }
                        ) {
                            Text(stringResource(Res.string.open))
                        }
                    }
                }
            }
        }
    }
}
