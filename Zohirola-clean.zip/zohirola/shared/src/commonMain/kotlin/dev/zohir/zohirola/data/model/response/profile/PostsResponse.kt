package dev.zohir.zohirola.data.model.response.profile

import dev.zohir.zohirola.data.model.response.Post
import kotlinx.serialization.Serializable

@Serializable
data class PostsResponse(
    val feed: List<Post>,
    val cursor: String?
)
