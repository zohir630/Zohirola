package dev.zohir.zohirola.ui.screens.post

import dev.zohir.zohirola.data.model.response.Post
import dev.zohir.zohirola.data.model.response.Reply
import dev.zohir.zohirola.data.model.response.ZohirolaError

class PostContract {

    data class PostContractState(
        val post: Post?,
        val isSaved: Boolean?,
        val replies: List<Reply>?,
        val error: ZohirolaError?
    )

}
