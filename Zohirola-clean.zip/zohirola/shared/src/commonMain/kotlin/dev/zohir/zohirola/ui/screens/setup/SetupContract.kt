package dev.zohir.zohirola.ui.screens.setup

import dev.zohir.zohirola.data.model.response.ZohirolaError

class SetupContract {

    data class State(
        val complete: Boolean,
        val loading: Boolean,
        val error: ZohirolaError?
    )

}
