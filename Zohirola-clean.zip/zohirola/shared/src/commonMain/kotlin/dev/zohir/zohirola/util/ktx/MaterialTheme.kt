package dev.zohir.zohirola.util.ktx

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val MaterialTheme.onSurfaceAlpha: Color
    @Composable
    @ReadOnlyComposable
    get() = this.colorScheme.onSurface.copy(alpha = 0.4f)

val MaterialTheme.noContent: Color
    @Composable
    @ReadOnlyComposable
    get() = this.colorScheme.surfaceColorAtElevation(4.dp)
