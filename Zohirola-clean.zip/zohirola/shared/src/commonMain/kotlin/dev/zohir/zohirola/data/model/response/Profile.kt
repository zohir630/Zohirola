package dev.zohir.zohirola.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    val id: String,
    val did: String,
    val name: String,
    val description: String,
    val avatar: String? = null,
    val banner: String? = null,
    val followers: Int = 0,
    val following: Int = 0,
    val posts: Int = 0,
    val lastFetched: Long? = null,
    val isFollowing: Boolean? = null
)
