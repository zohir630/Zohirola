package dev.zohir.zohirola.ui.theme

import androidx.compose.runtime.Composable

@Composable
actual fun getTheme(
    darkTheme: Boolean
): Theme = Theme(
    colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
    typography = typography
)
