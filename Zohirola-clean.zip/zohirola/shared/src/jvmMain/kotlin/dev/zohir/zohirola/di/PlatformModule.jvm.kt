package dev.zohir.zohirola.di

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.russhwolf.settings.ExperimentalSettingsApi
import com.russhwolf.settings.ExperimentalSettingsImplementation
import com.russhwolf.settings.coroutines.FlowSettings
import com.russhwolf.settings.datastore.DataStoreSettings
import kotlinx.coroutines.Dispatchers
import okio.Path.Companion.toPath
import org.koin.core.module.Module
import org.koin.core.qualifier.named
import org.koin.dsl.module

@OptIn(
    ExperimentalSettingsApi::class,
    ExperimentalSettingsImplementation::class
)
actual fun platformModule(): Module = module {
    single { Platform.JVM }
    single(named("io")) { Dispatchers.IO }
    single<String>(named("image")) {
        getProp("java.io.tmpdir")
    }
    single<String>(named("store")) {
        val os = getProp("os.name")
        val home = getProp("user.home")
        val user = getProp("user.name")
        when {
            os.contains("Linux") -> "/home/${user}/.local/share/zohirola"
            os.contains("Windows") -> "${home}/AppData/Local/Zohirola"
            os.contains("Mac OS X") -> "${home}/Library/Application Support/Zohirola"
            else -> getProp("java.io.tmpdir")
        }
    }
    single<FlowSettings> {
        DataStoreSettings(
            PreferenceDataStoreFactory.createWithPath {
                "${get<String>(named("store"))}/zohirola.preferences_pb".toPath()
            }
        )
    }
}

private fun getProp(
    property: String
) = try {
    System.getProperty(property);
} catch (_: Exception) {
    "/tmp"
}
