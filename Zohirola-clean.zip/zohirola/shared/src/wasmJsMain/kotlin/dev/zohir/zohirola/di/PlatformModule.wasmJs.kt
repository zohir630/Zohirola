package dev.zohir.zohirola.di

import com.russhwolf.settings.ExperimentalSettingsApi
import com.russhwolf.settings.ExperimentalSettingsImplementation
import com.russhwolf.settings.StorageSettings
import com.russhwolf.settings.coroutines.FlowSettings
import com.russhwolf.settings.coroutines.toFlowSettings
import com.russhwolf.settings.observable.makeObservable
import kotlinx.coroutines.Dispatchers
import org.koin.core.module.Module
import org.koin.core.qualifier.named
import org.koin.dsl.module

@OptIn(
    ExperimentalSettingsApi::class,
    ExperimentalSettingsImplementation::class
)
actual fun platformModule(): Module = module {
    single { Platform.Web }
    single(named("io")) { Dispatchers.Default }
    // WASM doesn't require ImageCachePath or StorePath as everything is in-memory
    single<FlowSettings> {
        StorageSettings()
            .makeObservable()
            .toFlowSettings()
    }
}
