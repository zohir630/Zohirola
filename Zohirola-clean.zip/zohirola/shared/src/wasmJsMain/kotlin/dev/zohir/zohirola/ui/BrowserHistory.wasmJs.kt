package dev.zohir.zohirola.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import kotlinx.browser.window

@OptIn(ExperimentalWasmJsInterop::class)
@Composable
actual fun BrowserHistorySync(authed: Boolean, navController: NavHostController) {
    val backStack by navController.currentBackStackEntryAsState()
    var ready by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val route = parseHash(window.location.hash)
        if (route != null && (authed || isPublicRoute(route))) {
            navController.navigateSyncable(route)
        }
        ready = true
    }

    LaunchedEffect(backStack, ready) {
        if (!ready) return@LaunchedEffect
        val hash = routeToHash(backStack) ?: return@LaunchedEffect
        val target = "#$hash"
        if (window.location.hash != target) {
            window.history.pushState(null, "", target)
        }
    }

    DisposableEffect(Unit) {
        window.onpopstate = { _ ->
            if (ready) {
                val route = parseHash(window.location.hash)
                if (route == null) {
                    navController.popBackStack()
                } else if (authed || isPublicRoute(route)) {
                    navController.navigateSyncable(route)
                }
            }
        }
        onDispose {
            window.onpopstate = null
        }
    }
}
