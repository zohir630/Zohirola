package dev.zohir.zohirola

import androidx.compose.ui.window.ComposeUIViewController

@Suppress("unused")
fun MainViewController() = ComposeUIViewController {
    App()
}
