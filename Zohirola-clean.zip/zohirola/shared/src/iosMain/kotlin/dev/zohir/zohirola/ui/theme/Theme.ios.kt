package dev.zohir.zohirola.ui.theme

import androidx.compose.runtime.Composable
import platform.UIKit.UITraitCollection
import platform.UIKit.UIUserInterfaceStyle
import platform.UIKit.currentTraitCollection

@Composable
actual fun getTheme(
    darkTheme: Boolean
): Theme = Theme(
    colorScheme = if (UITraitCollection.currentTraitCollection().userInterfaceStyle == UIUserInterfaceStyle.UIUserInterfaceStyleDark) DarkColorScheme else LightColorScheme,
    typography = typography
)
