package dev.zohir.zohirola

import dev.zohir.zohirola.di.installModules
import org.koin.core.context.startKoin

@Suppress("unused")
fun initKoin() {
    startKoin {
        installModules()
    }
}
