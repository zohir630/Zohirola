package dev.zohir.zohirola.di

import com.russhwolf.settings.ExperimentalSettingsApi
import com.russhwolf.settings.NSUserDefaultsSettings
import com.russhwolf.settings.coroutines.FlowSettings
import com.russhwolf.settings.coroutines.toFlowSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import org.koin.core.module.Module
import org.koin.core.qualifier.named
import org.koin.dsl.module
import platform.Foundation.NSApplicationSupportDirectory
import platform.Foundation.NSCachesDirectory
import platform.Foundation.NSSearchPathForDirectoriesInDomains
import platform.Foundation.NSUserDefaults
import platform.Foundation.NSUserDomainMask

@OptIn(ExperimentalSettingsApi::class)
actual fun platformModule(): Module = module {
    single { Platform.iOS }
    single(named("io")) { Dispatchers.IO }
    single<String>(named("image")) {
        "${NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true).firstOrNull()?.toString()}/images"
    }
    single<String>(named("store")) {
        NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, true)
            .firstOrNull()
            ?.toString()
            ?: ""
    }
    single<FlowSettings> {
        NSUserDefaultsSettings(NSUserDefaults()).toFlowSettings()
    }
}
