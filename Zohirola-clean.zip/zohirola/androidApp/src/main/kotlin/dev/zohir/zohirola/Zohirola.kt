package dev.zohir.zohirola

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Context.NOTIFICATION_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import dev.zohir.zohirola.di.installModules
import io.github.aakira.napier.DebugAntilog
import io.github.aakira.napier.Napier
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin

class Zohirola: Application() {

    private val defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler()

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Napier.base(DebugAntilog())
        }
        stopKoin()
        startKoin {
            androidContext(this@Zohirola)
            installModules()
        }
        Thread.setDefaultUncaughtExceptionHandler { t, exception ->
            sendCrashNotification(
                exception = exception,
                channel = ("exception" to "Crashes"),
                title = getString(R.string.zohirola_exception),
                description = getString(R.string.zohirola_exception_description)
            )
            defaultUncaughtExceptionHandler?.uncaughtException(t, exception)
        }
    }

}

private fun Context.getExceptionPendingIntent(
    exception: Throwable
): PendingIntent = PendingIntent.getActivity(
    this,
    1,
    Intent(this, ExceptionActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        putExtra("stacktrace", exception.stackTraceToString())
    },
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

private fun Context.sendCrashNotification(
    exception: Throwable,
    channel: Pair<String, String>,
    title: String,
    description: String
) {
    val (channelId, channelTitle) = channel
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(
                channelId,
                channelTitle,
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }
    val notification = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(R.drawable.ic_launcher_monochrome)
        .setContentTitle(title)
        .setContentText(description)
        .setContentIntent(getExceptionPendingIntent(exception))
        .setAutoCancel(true)
        .build()
    with(NotificationManagerCompat.from(this)) {
        if (ActivityCompat.checkSelfPermission(
                this@sendCrashNotification,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        notify(1, notification)
    }
}
