<h1 align="center">Zohirola</h1>
<div align="center">
    <p>An alternative Bluesky frontend</p>
    <p>⚠️ This app is in alpha ⚠️</p>
</div>

## About
Zohirola is an alternative frontend for Bluesky, providing local feeds and follows without a Bluesky account.

## Features
- Browse Bluesky
- See profiles, posts, and feeds
- Follow users
- Save posts
- Timeline
- All content proxied through a Zohirola instance

## Install
Download the latest APK from the [Releases](https://github.com/zohir630/Zohirola/releases) page,
or from the **Actions** tab (open a successful *Build APK* run and download the artifact).

### Build from source (Android)
Requirements: JDK 21 and the Android SDK.

```shell
./gradlew :androidApp:assembleDebug
```

### Build from source (Desktop)
```shell
./gradlew :desktopApp:packageReleaseDistributionForCurrentOS
```

## Developer
[Zohir](https://github.com/zohir630)

## License
Zohirola is licensed under the **GNU Affero General Public License v3.0 (AGPL-3.0)**. See [LICENSE.md](LICENSE.md) and [NOTICE](NOTICE).

Copyright © 2026 Zohir (modifications).
